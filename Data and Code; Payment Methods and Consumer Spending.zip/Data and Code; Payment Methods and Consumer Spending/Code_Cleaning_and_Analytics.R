# ------------------------------------------------------
# LOAD LIBRARIES
# ------------------------------------------------------
required_packages <- c(
  "broom", "car", "clubSandwich", "data.table", "dplyr", "e1071", "factoextra", 
  "FactoMineR", "forcats", "flextable", "ggplot2", "ggrepel", "grid", "gridExtra", "lme4",
  "lmtest", "lubridate", "modelsummary", "officer","partykit" ,"patchwork", "quantreg", 
  "rnaturalearth", "rnaturalearthdata", "sandwich" ,"scales", "sf", "skimr", "stringr", 
  "tidyr", "tidyverse", "VIM"
)

# Install missing packages
new_packages <- required_packages[!(required_packages %in% installed.packages()[, "Package"])]
if(length(new_packages)) install.packages(new_packages)

# Load all
lapply(required_packages, library, character.only = TRUE)


# --------------------------------------------------
# SET WORKING DIRECTORY
# --------------------------------------------------

# Change this to your own path
#setwd("C:/Users/.../Data and Code; Payment Methods and Consumer Spending")
setwd("C:/Users/deeni/OneDrive/Documenten/@Thesis data science/Data and Code; Payment Methods and Consumer Spending")

# --------------------------------------------------
# LOAD RAW DATA & INITIAL CLEANING
# --------------------------------------------------

space_data <- read_csv("Data/SPACE Public Use File.csv")

# Drop 1 (redundant row index)
space_data <- space_data %>%
  select(-1)
# Replace bad codes (999997 etc.) with NA in ALL  columns
bad_codes <- c(999997, 999998, 999999)
space_data <- space_data %>%
  mutate(across(everything(), ~ ifelse(. %in% bad_codes, NA, .)))

# Create object with % missing per variable
missing_summary <- space_data %>%
  summarise(across(everything(), ~ mean(is.na(.)) * 100)) %>%
  pivot_longer(cols = everything(), names_to = "Variable", values_to = "Missing_Percent") %>%
  arrange(desc(Missing_Percent))

# ------------------------------------------------------
# FUNCTIONS & SETTINGS
# ------------------------------------------------------

# Encode binary responses, Yes/No recoding
encode_response <- function(x) {
  case_when(
    x == 1 ~ "Yes",
    x == 0 ~ "No",
    TRUE ~ as.character(x)
  )
}

theme_set(
  theme_minimal(base_family = "Times New Roman", base_size = 14) %+replace%
    theme(plot.margin = margin(t = 0, r = 5, b = 0, l = 5, unit = "mm"))
)


# ------------------------------------------------------
# Drop variables with more then 10% missing values 
# ------------------------------------------------------

space_data <- space_data %>%
  select(-DEPCHILDREN, -D6_2A, -D6_2B, -QQ1B_2, -QQ14A_6, -QQ14A_7, -QQ14A_8,
         -QA2A, -QA3A, -QA2B, -QA3B, -QA22, -QQ2F, -QC2_2, -QC2_3, -QC2_4, -QC2_5, 
         -QC2_6, -QC2_7, -QC2_9, -QC2_10, -QC2_11, -QC3_2, -QC3_3, -QC3_4, -QC3_5, 
         -QC3_6, -QC3_7, -QC3_9, -QC3_10, -QC3_11, -QC5_2, -QC5_3, -QC5_4, -QC5_5, 
         -QC5_6, -QC5_7, -QC5_9, -QC5_10, -QC5_11, -QQ3A, -QQ11B, -QQ10, -QB7_1, 
         -QB7_21, -QB7_22, -QB7_23, -QB7_24, -QB7_25, -QB7_26, -QB7_3, 
         -QB8, -QQ14A_1, -QQ14A_2, -QQ14A_3, -QQ14A_4, -QQ14A_5,
         # Online Transactions
         -QB3_1, -QB3_2, -QB3_3, -QB3_4, -QB3_5, -QB3_6, -QB3_7, -QB3_8,
         -QB1_1, -QB1_2, -QB1_3, -QB1_4, -QB1_5, -QB1_6, -QB1_7, -QB1_8,
         -QB4_1, -QB4_2, -QB4_3, -QB4_4, -QB4_5, -QB4_6, -QB4_7, -QB4_8,
         # Payment information, more than 10% missing after long form
         -QA7AI_1, -QA7AI_2, -QA7AI_3, -QA7AI_4, -QA7AI_5, -QA7AI_6, -QA7AI_7, -QA7AI_8,
         -QA7BI_1, -QA7BI_2, -QA7BI_3, -QA7BI_4, -QA7BI_5, -QA7BI_6, -QA7BI_7, -QA7BI_8 
         )

# ------------------------------------------------------
# CLEANING: Demographics
# ------------------------------------------------------

# Rename demographic & core columns
space_data <- space_data %>%
  rename(
    Round = ROUND,
    Field = FIELD,
    Month = MONTH,
    Day = DAY,
    Year = YEAR,
    Country = COUNTRY,
    Language = LANG,
    DEM_Age = AGE,
    DEM_Education = EDUCATION,
    DEM_Income = INCOME,
    DEM_HouseholdSize = HHSIZE,
    DEM_Urban = URBAN,
    DEM_Gender = D1,
    DEM_ActivityStatus = D6_1
  )

# KNN imputation (on selected demographics)
knn_vars <- c("DEM_Education", "DEM_Income", "DEM_HouseholdSize", "DEM_Gender", "DEM_ActivityStatus")
space_data <- kNN(space_data, variable = knn_vars, k = 5, imp_var = FALSE)

space_data <- space_data %>%
  mutate(
    Country = case_when(
      Country == "AT" ~ "Austria",
      Country == "BE" ~ "Belgium",
      Country == "CY" ~ "Cyprus",
      Country == "EE" ~ "Estonia",
      Country == "ES" ~ "Spain",
      Country == "FI" ~ "Finland",
      Country == "FR" ~ "France",
      Country == "GR" ~ "Greece",
      Country == "HR" ~ "Croatia",
      Country == "IE" ~ "Ireland",
      Country == "IT" ~ "Italy",
      Country == "LT" ~ "Lithuania",
      Country == "LU" ~ "Luxembourg",
      Country == "LV" ~ "Latvia",
      Country == "MT" ~ "Malta",
      Country == "PT" ~ "Portugal",
      Country == "SI" ~ "Slovenia",
      Country == "SK" ~ "Slovakia",
      TRUE ~ Country  # behoud originele waarde als geen match
    ),
    Language = case_when(
      as.character(Language) == "11" ~ "Dutch",
      as.character(Language) == "12" ~ "French",
      as.character(Language) == "13" ~ "German",
      as.character(Language) == "14" ~ "Estonian",
      as.character(Language) == "15" ~ "Russian",
      as.character(Language) == "16" ~ "English",
      as.character(Language) == "17" ~ "Greek",
      as.character(Language) == "18" ~ "Spanish",
      as.character(Language) == "19" ~ "Italian",
      as.character(Language) == "20" ~ "Latvian",
      as.character(Language) == "21" ~ "Lithuanian",
      as.character(Language) == "22" ~ "Luxembourgish",
      as.character(Language) == "23" ~ "Maltese",
      as.character(Language) == "24" ~ "Portuguese",
      as.character(Language) == "25" ~ "Slovenian",
      as.character(Language) == "26" ~ "Slovakian",
      as.character(Language) == "27" ~ "Finnish",
      as.character(Language) == "28" ~ "Swedish",
      as.character(Language) == "29" ~ "Croatian",
      TRUE ~ as.character(Language)  # behoud originele waarde
    )
  )

# Label & factor categorical demographic variables
space_data <- space_data %>%
  mutate(
    DEM_ActivityStatus = case_when(
      DEM_ActivityStatus == 1 ~ "Self-employed",
      DEM_ActivityStatus == 2 ~ "Employee",
      DEM_ActivityStatus == 3 ~ "Without professional activity or student",
      TRUE ~ encode_response(DEM_ActivityStatus)
    ),
    DEM_Gender = case_when(
      DEM_Gender == 1 ~ "Male",
      DEM_Gender == 2 ~ "Female",
      DEM_Gender == 3 ~ "Other, non-binary",
      TRUE ~ as.character(DEM_Gender)
    ),
    DEM_Age = case_when(
      DEM_Age == 1 ~ "18–24", DEM_Age == 2 ~ "25–29", DEM_Age == 3 ~ "30–34",
      DEM_Age == 4 ~ "35–39", DEM_Age == 5 ~ "40–44", DEM_Age == 6 ~ "45–49",
      DEM_Age == 7 ~ "50–54", DEM_Age == 8 ~ "55–59", DEM_Age == 9 ~ "60–64",
      DEM_Age == 10 ~ "65–69", DEM_Age == 11 ~ "70–74", DEM_Age == 12 ~ "75+",
      TRUE ~ as.character(DEM_Age)
    ),
    DEM_Education = case_when(
      DEM_Education == 1 ~ "Primary/lower secondary education",
      DEM_Education == 2 ~ "Upper/post-secondary education",
      DEM_Education == 3 ~ "University/PhD/research",
      TRUE ~ as.character(DEM_Education)
    ),
    DEM_Income = case_when(
      DEM_Income == 1 ~ "EUR 750 or less",
      DEM_Income == 2 ~ "EUR 751–1,500",
      DEM_Income == 3 ~ "EUR 1,501–2,500",
      DEM_Income == 4 ~ "EUR 2,501–4,000",
      DEM_Income == 5 ~ "More than EUR 4,000",
      TRUE ~ as.character(DEM_Income)
    ),
    DEM_Urban = case_when(
      DEM_Urban == 0 ~ "Rural",
      DEM_Urban == 1 ~ "Urban",
      TRUE ~ as.character(DEM_Urban)
    ),
    Survey_Month = factor(Month,
                          levels = c(9, 10, 11, 4, 5, 6),
                          labels = c("September 2023", "October 2023", "November 2023",
                                     "April 2024", "May 2024", "June 2024"),
                          ordered = TRUE),

    Field = factor(Field, levels = c(1, 2), labels = c("CATI", "CAWI")),
    Day = factor(Day, levels = 1:7,
                 labels = c("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"))
  ) 

# Drop now-redundant time variables
space_data <- space_data %>%
  select(-c(Round, Year, Month))

# Demographic variables to convert to factors
demographic_vars <- c(
  "DEM_Age", "DEM_Education", "DEM_Income", "DEM_HouseholdSize", "Day",
  "DEM_Urban", "DEM_Gender", "DEM_ActivityStatus", "Field", "Country", "Language"
)

# Convert selected demographic variables to factors
space_data <- space_data %>%
  mutate(across(all_of(demographic_vars), ~ as.factor(.)))

# ------------------------------------------------------
# CLEANING: OWNERSHIP
# ------------------------------------------------------

# Rename and encode all ownership-related variables (except KNN one)
space_data <- space_data %>%
  rename(
    OWN_BankAccount = QQ1A_1,      
    OWN_PaymentCard = QQ1A_2,      
    OWN_NoPaymentMethod = QQ1A_4,  
    OWN_OtherPaymentMethod = QQ1A_5, 
    OWN_MobilePaymentDevice = QQ1A_6,
    OWN_Crypto = QQ1B_1,
    OWN_Mortgage = D10_1,
    OWN_ConsumerLoan = D10_2,
    OWN_SavingsAccount = D10_3,
    OWN_OnlineBanking = D10_4,
    OWN_Investments = D10_6,
    OWN_NoFinancialProducts = D10_7,
    OWN_LifeInsurance = D10_9,
    OWN_PensionFund = D10_10
  ) %>%
  mutate(across(
    c(
      OWN_BankAccount, OWN_PaymentCard, OWN_NoPaymentMethod, OWN_OtherPaymentMethod,
      OWN_MobilePaymentDevice, OWN_Mortgage, OWN_ConsumerLoan, OWN_SavingsAccount,
      OWN_OnlineBanking, OWN_Investments, OWN_NoFinancialProducts,
      OWN_LifeInsurance, OWN_PensionFund
    ),
    ~ as.factor(encode_response(.))
  ))

# KNN imputation (own crypto)
space_data <- kNN(space_data, variable = "OWN_Crypto", k = 5, imp_var = FALSE)
space_data <- space_data %>%
  mutate(OWN_Crypto = as.factor(encode_response(OWN_Crypto)))

space_data <- space_data %>%
  rename(
    OWN_Smartphone = D9_1,
    OWN_Smartwatch = D9_2,
    OWN_NoSmartphoneOrSmartwatch = D9_3,
    INTERNET_Usage = D8
  ) %>%
  mutate(
    INTERNET_Usage = case_when(
      INTERNET_Usage == 1 ~ "Every or almost every day",
      INTERNET_Usage == 2 ~ "Two or three times a week",
      INTERNET_Usage == 3 ~ "About once a week",
      INTERNET_Usage == 4 ~ "Two or three times a month",
      INTERNET_Usage == 5 ~ "Less often",
      INTERNET_Usage == 6 ~ "Never",
      INTERNET_Usage == 7 ~ "No internet access",
      TRUE ~ encode_response(INTERNET_Usage)
    )
  ) %>%
  mutate(across(
    c(OWN_Smartphone, OWN_Smartwatch, OWN_NoSmartphoneOrSmartwatch),
    ~ encode_response(.)
  )) %>%
  mutate(across(
    c(OWN_Smartphone, OWN_Smartwatch, OWN_NoSmartphoneOrSmartwatch, INTERNET_Usage),
    ~ as.factor(.)
  ))


# ------------------------------------------------------
# CLEANING: RECURRING PAYMENTS
# ------------------------------------------------------

# Rename recurring and cash variables
space_data <- space_data %>%
  rename(
    RECUR_Utilities = QC1_2,
    RECUR_Insurance = QC1_3,
    RECUR_TelephoneInternet = QC1_4,
    RECUR_Taxes = QC1_5,
    RECUR_Subscriptions = QC1_6,
    RECUR_Mortgage = QC1_7,
    RECUR_SchoolFees = QC1_9,
    RECUR_LoanRepayment = QC1_10,
    RECUR_Rent = QC1_11,
    CASH_StartingAmount = QA1
  )

# KNN imputation (on recurring + cash)
recur_knn_vars_1 <- c("RECUR_Utilities", "RECUR_Insurance", "RECUR_TelephoneInternet",
                      "RECUR_Taxes", "RECUR_Subscriptions")

recur_knn_vars_2 <- c("RECUR_Mortgage", "RECUR_SchoolFees", "RECUR_LoanRepayment",
                      "RECUR_Rent", "CASH_StartingAmount")

space_data <- kNN(space_data, variable = recur_knn_vars_1, k = 5, imp_var = FALSE)
space_data <- kNN(space_data, variable = recur_knn_vars_2, k = 5, imp_var = FALSE)

# Encode RECUR vars as Yes/No
recur_vars <- c("RECUR_Utilities", "RECUR_Insurance", "RECUR_TelephoneInternet", "RECUR_Taxes",
                "RECUR_Subscriptions", "RECUR_Mortgage", "RECUR_SchoolFees", 
                "RECUR_LoanRepayment", "RECUR_Rent")

space_data <- space_data %>%
  mutate(across(all_of(recur_vars), encode_response)) %>%
  mutate(across(all_of(recur_vars), ~ as.factor(.)))

# ------------------------------------------------------
# CLEANING: PREFERNCES
# ------------------------------------------------------

# KNN imputation (3 groups)
knn_vars_phase2_1 <- c("QQ3", "QQ4C", "QQ17", "QQ8", "QQ9")
knn_vars_phase2_2 <- c("QQ15", "QQ1E", "QQ2", "QQ2B", "QQ11A")
knn_vars_phase2_3 <- c("QQ16_1", "QQ16_2", "QQ16_3", "QQ16_4")
space_data <- kNN(space_data, variable = knn_vars_phase2_1, k = 5, imp_var = FALSE)
space_data <- kNN(space_data, variable = knn_vars_phase2_2, k = 5, imp_var = FALSE)
space_data <- kNN(space_data, variable = knn_vars_phase2_3, k = 5, imp_var = FALSE)

# Rename variables (preferences, advantages, access, privacy, NPS, etc.)
space_data <- space_data %>%
  rename(
    PREF_CashVsCardGeneral = QQ3,
    PREF_CashImportance = QQ4C,
    PREF_P2P_Payment = QQ17,
    INCOME_CashShare = QQ8,
    DIGI_Assistance = QQ15,
    INSTANT_Transfer = QQ1E,
    CASH_WithdrawEase = QQ2,
    CASH_WithdrawJourney = QQ2B,
    CASH_ATMFees = QQ11A,
    PRIV_WishMorePrivacy = QQ16_1,
    PRIV_DataConcern = QQ16_2,
    PRIV_NoConcerns = QQ16_3,
    PRIV_NoDigitalPayments = QQ16_4,
    CASH_Reserves = QQ9,
    # Cash advantages
    ADV_Cash_Acceptance = QQ13A_1, ADV_Cash_Faster = QQ13A_2, ADV_Cash_Privacy = QQ13A_3,
    ADV_Cash_Easier = QQ13A_4, ADV_Cash_Safer = QQ13A_5, ADV_Cash_Immediate = QQ13A_6,
    ADV_Cash_SpendingAwareness = QQ13A_7, ADV_Cash_Other = QQ13A_8, ADV_Cash_NoUse = QQ13A_9,
    ADV_Cash_None = QQ13A_10,
    # Card advantages
    ADV_Card_Acceptance = QQ13B_1, ADV_Card_Faster = QQ13B_2, ADV_Card_Easier = QQ13B_3,
    ADV_Card_Safer = QQ13B_4, ADV_Card_NoCashCarry = QQ13B_5, ADV_Card_SpendingAwareness = QQ13B_6,
    ADV_Card_Other = QQ13B_7, ADV_Card_None = QQ13B_8, ADV_Card_NoUse = QQ13B_9,
    # NPS
    NPS_EasierToUse = QQ18_1, NPS_Cheaper = QQ18_2, NPS_Security = QQ18_3,
    NPS_Privacy = QQ18_4, NPS_InnovativeFunctions = QQ18_5, NPS_Faster = QQ18_6,
    NPS_Incentives = QQ18_7, NPS_Recommendations = QQ18_8, NPS_OfflineUse = QQ18_9,
    NPS_NotInterested = QQ18_10
  )

# Recode categorical variables
space_data <- space_data %>%
  mutate(
    PREF_CashVsCardGeneral = case_when(
      PREF_CashVsCardGeneral == 1 ~ "Cash",
      PREF_CashVsCardGeneral == 2 ~ "Card or other cashless payment",
      PREF_CashVsCardGeneral == 3 ~ "No clear preference",
      TRUE ~ encode_response(PREF_CashVsCardGeneral)
    ),
    PREF_CashImportance = case_when(
      PREF_CashImportance == 1 ~ "Very important",
      PREF_CashImportance == 2 ~ "Fairly important",
      PREF_CashImportance == 3 ~ "Not so important",
      PREF_CashImportance == 4 ~ "Not important at all",
      TRUE ~ encode_response(PREF_CashImportance)
    ),
    PREF_P2P_Payment = case_when(
      PREF_P2P_Payment == 1 ~ "Cash",
      PREF_P2P_Payment == 2 ~ "Bank transfers",
      PREF_P2P_Payment == 3 ~ "Mobile or other online payments",
      PREF_P2P_Payment == 4 ~ "No clear preference",
      TRUE ~ NA_character_
    ),
    INCOME_CashShare = case_when(
      INCOME_CashShare == 1 ~ "None",
      INCOME_CashShare == 2 ~ "Up to a quarter",
      INCOME_CashShare == 3 ~ "Between a quarter and a half",
      INCOME_CashShare == 4 ~ "Half of your regular income is in cash",
      INCOME_CashShare == 5 ~ "Between half and three-quarters",
      INCOME_CashShare == 6 ~ "More than three quarters",
      INCOME_CashShare == 99997 ~ "I have no regular income",
      TRUE ~ encode_response(INCOME_CashShare)
    ),
    INSTANT_Transfer = case_when(
      INSTANT_Transfer == 1 ~ "Yes I can, and I use the option",
      INSTANT_Transfer == 2 ~ "No I can’t",
      INSTANT_Transfer == 3 ~ "Heard about it, but unsure",
      INSTANT_Transfer == 4 ~ "Never heard about it",
      INSTANT_Transfer == 6 ~ "Yes I can, but I don’t use the option",
      TRUE ~ encode_response(INSTANT_Transfer)
    ),
    DIGI_Assistance = case_when(
      DIGI_Assistance == 1 ~ "Does not pay online",
      DIGI_Assistance == 2 ~ "Yes, needs assistance",
      DIGI_Assistance == 3 ~ "No, does not need assistance",
      TRUE ~ encode_response(DIGI_Assistance)
    ),
    CASH_WithdrawEase = case_when(
      CASH_WithdrawEase == 1 ~ "Very easy",
      CASH_WithdrawEase == 2 ~ "Fairly easy",
      CASH_WithdrawEase == 3 ~ "Fairly difficult",
      CASH_WithdrawEase == 4 ~ "Very difficult",
      TRUE ~ encode_response(CASH_WithdrawEase)
    ),
    CASH_WithdrawJourney = case_when(
      CASH_WithdrawJourney == 1 ~ "Special journey",
      CASH_WithdrawJourney == 2 ~ "Combined with commute",
      CASH_WithdrawJourney == 3 ~ "Combined with other activities",
      CASH_WithdrawJourney == 4 ~ "Never withdraw cash",
      TRUE ~ encode_response(CASH_WithdrawJourney)
    ),
    CASH_ATMFees = case_when(
      CASH_ATMFees == 1 ~ "Always pay fee",
      CASH_ATMFees == 2 ~ "Most of the time",
      CASH_ATMFees == 3 ~ "Sometimes",
      CASH_ATMFees == 4 ~ "Rarely",
      CASH_ATMFees == 5 ~ "Never",
      TRUE ~ encode_response(CASH_ATMFees)
    )
  ) %>%
  mutate(across(
    c(ADV_Cash_Acceptance, ADV_Cash_Faster, ADV_Cash_Privacy, ADV_Cash_Easier, 
      ADV_Cash_Safer, ADV_Cash_Immediate, ADV_Cash_SpendingAwareness, ADV_Cash_Other, 
      ADV_Cash_NoUse, ADV_Cash_None, ADV_Card_Acceptance, ADV_Card_Faster, 
      ADV_Card_Easier, ADV_Card_Safer, ADV_Card_NoCashCarry, ADV_Card_SpendingAwareness, 
      ADV_Card_Other, ADV_Card_None, ADV_Card_NoUse, 
      PRIV_WishMorePrivacy, PRIV_DataConcern, PRIV_NoConcerns, PRIV_NoDigitalPayments, 
      NPS_EasierToUse, NPS_Cheaper, 
      NPS_Security, NPS_Privacy, NPS_InnovativeFunctions, NPS_Faster, NPS_Incentives, 
      NPS_Recommendations, NPS_OfflineUse, NPS_NotInterested, 
      CASH_Reserves),
    encode_response
  )) %>%
  mutate(across(
    c(PREF_CashVsCardGeneral, PREF_CashImportance, PREF_P2P_Payment, INCOME_CashShare,
      INSTANT_Transfer, DIGI_Assistance, CASH_WithdrawEase, CASH_WithdrawJourney, 
      CASH_ATMFees, ADV_Cash_Acceptance, ADV_Cash_Faster, ADV_Cash_Privacy, ADV_Cash_Easier, 
      ADV_Cash_Safer, ADV_Cash_Immediate, ADV_Cash_SpendingAwareness, ADV_Cash_Other, 
      ADV_Cash_NoUse, ADV_Cash_None, ADV_Card_Acceptance, ADV_Card_Faster, ADV_Card_Easier, 
      ADV_Card_Safer, ADV_Card_NoCashCarry, ADV_Card_SpendingAwareness, ADV_Card_Other, 
      ADV_Card_None, ADV_Card_NoUse, PRIV_WishMorePrivacy, PRIV_DataConcern, PRIV_NoConcerns, 
      PRIV_NoDigitalPayments, NPS_EasierToUse, NPS_Cheaper, NPS_Security, NPS_Privacy, 
      NPS_InnovativeFunctions, NPS_Faster, NPS_Incentives, NPS_Recommendations, 
      NPS_OfflineUse, NPS_NotInterested, CASH_Reserves),
    ~ as.factor(.)
  ))

# ------------------------------------------------------
# CLEANING: ACCEPTANCE & PAYMENT ISSUES
# ------------------------------------------------------

# KNN imputation 
issue_knn_vars <- c("QA10_1", "QA10_2", "QA10_3", "QA10_4", "INTERNET_Usage")  
space_data <- kNN(space_data, variable = issue_knn_vars, k = 5, imp_var = FALSE)

# Rename, encode, and factorise payment acceptance & issue variables
space_data <- space_data %>%
  rename(
    ACCEPT_CashNotAccepted = QA9_1,
    ACCEPT_DigitalNotAccepted = QA9_2,
    ACCEPT_DigitalAboveThreshold = QA9_3,
    ACCEPT_AlwaysAccepted = QA9_4,
    ACCEPT_NoPOSPayments = QA9_5,
    ISSUE_CardPayment = QA10_1,
    ISSUE_MobilePayment = QA10_2,
    ISSUE_CashRegister = QA10_3,
    ISSUE_NoProblems = QA10_4
  ) %>%
  mutate(across(
    c(ACCEPT_CashNotAccepted, ACCEPT_DigitalNotAccepted,
      ACCEPT_DigitalAboveThreshold, ACCEPT_AlwaysAccepted,
      ACCEPT_NoPOSPayments, ISSUE_CardPayment, ISSUE_MobilePayment,
      ISSUE_CashRegister, ISSUE_NoProblems),
    ~ as.factor(encode_response(.))
  ))

# ------------------------------------------------------
# CLEANING: REGION & DIARY MAPPING
# ------------------------------------------------------

# Rename and prepare diary payment variables
space_data <- space_data %>%
  rename(
    DuringDiary_CashWithdrawal = Q1_1,
    DuringDiary_ReceivedCash = Q1_2,
    DuringDiary_PaymentPOS = Q1_3,
    DuringDiary_PickupPayment = Q1_4,
    DuringDiary_CourierPayment = Q1_5,
    DuringDiary_P2PPayment = Q1_6,
    DuringDiary_OnlinePayment = Q1_7,
    DuringDiary_HomeServicePayment = Q1_8
  )

diary_vars <- c(
  "DuringDiary_CashWithdrawal", "DuringDiary_ReceivedCash", "DuringDiary_PaymentPOS",
  "DuringDiary_PickupPayment", "DuringDiary_CourierPayment", "DuringDiary_P2PPayment",
  "DuringDiary_OnlinePayment", "DuringDiary_HomeServicePayment"
)

# Impute and encode
space_data <- kNN(space_data, variable = diary_vars, k = 5, imp_var = FALSE) %>%
  mutate(across(all_of(diary_vars), encode_response))

# Rename regional columns
space_data <- space_data %>%
  rename(
    Region_Austria = D3_AT, Region_Belgium = D3_BE, Region_Estonia = D3_EE, Region_Spain = D3_ES,
    Region_Finland = D3_FI, Region_France = D3_FR, Region_Greece = D3_GR, Region_Croatia = D3_HR,
    Region_Ireland = D3_IE, Region_Italy = D3_IT, Region_Lithuania = D3_LT, Region_Luxembourg = D3_LU,
    Region_Latvia = D3_LV, Region_Portugal = D3_PT, Region_Slovenia = D3_SI, Region_Slovakia = D3_SK,
    Region_Cyprus = D3_CY, Region_Malta = D3_MT
  )

# List of region columns
region_columns <- c("Region_Austria", "Region_Belgium", "Region_Estonia", "Region_Spain", 
                    "Region_Finland", "Region_France", "Region_Greece", "Region_Croatia", 
                    "Region_Ireland", "Region_Italy", "Region_Lithuania", "Region_Luxembourg", 
                    "Region_Latvia", "Region_Portugal", "Region_Slovenia", "Region_Slovakia", 
                    "Region_Cyprus", "Region_Malta")

# Convert to character and remove invalid regions
space_data <- space_data %>%
  mutate(across(all_of(region_columns), as.character)) %>%
  mutate(
    Region_Austria   = if_else(Country != "Austria",   NA_character_, Region_Austria),
    Region_Belgium   = if_else(Country != "Belgium",   NA_character_, Region_Belgium),
    Region_Estonia   = if_else(Country != "Estonia",   NA_character_, Region_Estonia),
    Region_Spain     = if_else(Country != "Spain",     NA_character_, Region_Spain),
    Region_Finland   = if_else(Country != "Finland",   NA_character_, Region_Finland),
    Region_France    = if_else(Country != "France",    NA_character_, Region_France),
    Region_Greece    = if_else(Country != "Greece",    NA_character_, Region_Greece),
    Region_Croatia   = if_else(Country != "Croatia",   NA_character_, Region_Croatia),
    Region_Ireland   = if_else(Country != "Ireland",   NA_character_, Region_Ireland),
    Region_Italy     = if_else(Country != "Italy",     NA_character_, Region_Italy),
    Region_Lithuania = if_else(Country != "Lithuania", NA_character_, Region_Lithuania),
    Region_Luxembourg= if_else(Country != "Luxembourg",NA_character_, Region_Luxembourg),
    Region_Latvia    = if_else(Country != "Latvia",    NA_character_, Region_Latvia),
    Region_Portugal  = if_else(Country != "Portugal",  NA_character_, Region_Portugal),
    Region_Slovenia  = if_else(Country != "Slovenia",  NA_character_, Region_Slovenia),
    Region_Slovakia  = if_else(Country != "Slovakia",  NA_character_, Region_Slovakia),
    Region_Cyprus    = if_else(Country != "Cyprus",    NA_character_, Region_Cyprus),
    Region_Malta     = if_else(Country != "Malta",     NA_character_, Region_Malta)
  )

# Map region codes to names (1/2)
space_data <- space_data %>%
  mutate(
    Region_Austria = case_when(
      Region_Austria == "1" ~ "Burgenland - Niederösterreich",
      Region_Austria == "2" ~ "Wien",
      Region_Austria == "3" ~ "Kärnten",
      Region_Austria == "4" ~ "Steiermark",
      Region_Austria == "5" ~ "Oberösterreich",
      Region_Austria == "6" ~ "Salzburg",
      Region_Austria == "7" ~ "Tirol - Vorarlberg",
      TRUE ~ NA_character_
    ),
    Region_Belgium = case_when(
      Region_Belgium == "1" ~ "Brussels",
      Region_Belgium == "2" ~ "Antwerpen",
      Region_Belgium == "3" ~ "Limburg",
      Region_Belgium == "4" ~ "Oost-Vlaanderen",
      Region_Belgium == "5" ~ "Vlaams-Brabant - Waals-Brabant",
      Region_Belgium == "6" ~ "West-Vlaanderen",
      Region_Belgium == "7" ~ "Henegouwen",
      Region_Belgium == "8" ~ "Luik",
      Region_Belgium == "9" ~ "Namen - Luxembourg",
      TRUE ~ NA_character_
    ),
    Region_Spain = case_when(
      Region_Spain == "1" ~ "Galicia - Asturias - Cantabria",
      Region_Spain == "2" ~ "Pais Vasco - Navarra - La Rioja - Aragon",
      Region_Spain == "3" ~ "Madrid",
      Region_Spain == "4" ~ "Castilla y Leon - Castilla-La-Mancha",
      Region_Spain == "5" ~ "Cataluna",
      Region_Spain == "6" ~ "Valenciana - Illes Balears",
      Region_Spain == "7" ~ "Andalucia - Murcia - Ceuta - Melilla",
      Region_Spain == "8" ~ "Canarias",
      TRUE ~ NA_character_
    ),
    Region_France = case_when(
      Region_France == "1" ~ "Ile-de-France",
      Region_France == "2" ~ "Bretagne - Pays de la Loire",
      Region_France == "3" ~ "Normandie - Centre-Val de Loire",
      Region_France == "4" ~ "Bourgogne - Franche-Comté",
      Region_France == "5" ~ "Nouvelle-Aquitaine",
      Region_France == "6" ~ "Occitanie",
      Region_France == "7" ~ "Auvergne - Rhône-Alpes",
      Region_France == "8" ~ "Provence-Alpes-Côte d'Azur - Corse",
      Region_France == "9" ~ "Hauts-de-France - Grand Est",
      TRUE ~ NA_character_
    ),
    Region_Italy = case_when(
      Region_Italy == "1" ~ "Piemonte - Valle d'Aosta - Liguria",
      Region_Italy == "2" ~ "Lombardia",
      Region_Italy == "3" ~ "Trentino-Alto Adige - Veneto - Friuli Venezia Giulia",
      Region_Italy == "4" ~ "Emilia-Romagna",
      Region_Italy == "5" ~ "Toscana - Umbria - Marche",
      Region_Italy == "6" ~ "Lazio",
      Region_Italy == "7" ~ "Abruzzo - Molise",
      Region_Italy == "8" ~ "Campania - Puglia - Basilicata - Calabria",
      Region_Italy == "9" ~ "Sicilia - Sardegna",
      TRUE ~ NA_character_
    ),
    Region_Portugal = case_when(
      Region_Portugal == "1" ~ "Norte",
      Region_Portugal == "2" ~ "Centro",
      Region_Portugal == "3" ~ "Lisboa",
      Region_Portugal == "4" ~ "Alentejo - Algarve",
      Region_Portugal == "5" ~ "Açores - Madeira",
      TRUE ~ NA_character_
    ),
    Region_Finland = case_when(
      Region_Finland == "1" ~ "Uusimaa",
      Region_Finland == "2" ~ "Länsi-Suomi",
      Region_Finland == "3" ~ "Pohjois- ja Itä-Suomi",
      Region_Finland == "4" ~ "Etelä-Suomi",
      TRUE ~ NA_character_
    ),
    Region_Greece = case_when(
      Region_Greece == "1" ~ "Attiki",
      Region_Greece == "2" ~ "Voreia Ellada",
      Region_Greece == "3" ~ "Kentriki Ellada",
      Region_Greece == "4" ~ "Nisia Aigaiou, Kriti",
      TRUE ~ NA_character_
    )
  )

space_data <- space_data %>%
  mutate(
    # Croatia
    Region_Croatia = case_when(
      Region_Croatia == "1" ~ "Sjeverna Hrvatska",
      Region_Croatia == "2" ~ "Središnja i Istočna Hrvatska",
      Region_Croatia == "3" ~ "Jadranska Hrvatska",
      TRUE ~ NA_character_
    ),
    Region_Ireland = case_when(
      Region_Ireland == "1" ~ "Border - Midland",
      Region_Ireland == "2" ~ "West",
      Region_Ireland == "3" ~ "Dublin",
      Region_Ireland == "4" ~ "Mid-East",
      Region_Ireland == "5" ~ "Mid-West",
      Region_Ireland == "6" ~ "South-East",
      Region_Ireland == "7" ~ "South-West",
      TRUE ~ NA_character_
    ),
    Region_Lithuania = case_when(
      Region_Lithuania == "1" ~ "Alytus",
      Region_Lithuania == "2" ~ "Kaunas",
      Region_Lithuania == "3" ~ "Klaipėda",
      Region_Lithuania == "4" ~ "Marijampolė",
      Region_Lithuania == "5" ~ "Panevėžys",
      Region_Lithuania == "6" ~ "Šiauliai",
      Region_Lithuania == "7" ~ "Tauragė",
      Region_Lithuania == "8" ~ "Telšiai",
      Region_Lithuania == "9" ~ "Utena",
      Region_Lithuania == "10" ~ "Vilnius",
      TRUE ~ NA_character_
    ),
    Region_Luxembourg = case_when(
      Region_Luxembourg == "1" ~ "Luxembourg",
      TRUE ~ NA_character_
    ),
    Region_Latvia = case_when(
      Region_Latvia == "1" ~ "Riga",
      Region_Latvia == "2" ~ "Vidzeme",
      Region_Latvia == "3" ~ "Kurzeme",
      Region_Latvia == "4" ~ "Zemgale",
      Region_Latvia == "5" ~ "Latgale",
      TRUE ~ NA_character_
    ),
    Region_Slovenia = case_when(
      Region_Slovenia == "1" ~ "Vzhodna Slovenija",
      Region_Slovenia == "2" ~ "Zahodna Slovenija",
      TRUE ~ NA_character_
    ),
    Region_Slovakia = case_when(
      Region_Slovakia == "1" ~ "Bratislavský kraj",
      Region_Slovakia == "2" ~ "Západné Slovensko",
      Region_Slovakia == "3" ~ "Stredné Slovensko",
      Region_Slovakia == "4" ~ "Východné Slovensko",
      TRUE ~ NA_character_
    ),
    Region_Cyprus = case_when(
      Region_Cyprus == "1" ~ "Nicosia",
      Region_Cyprus == "2" ~ "Limassol",
      Region_Cyprus == "3" ~ "Larnaca",
      Region_Cyprus == "4" ~ "Famagusta",
      Region_Cyprus == "5" ~ "Paphos",
      TRUE ~ NA_character_
    ),
    Region_Malta = case_when(
      Region_Malta == "1" ~ "Northern",
      Region_Malta == "2" ~ "Western",
      Region_Malta == "3" ~ "Southern",
      Region_Malta == "4" ~ "Gozo",
      TRUE ~ NA_character_
    )
  )

# Combine regions into one column
space_data <- space_data %>%
  mutate(
    DEM_Region = coalesce(
      Region_Austria, Region_Belgium, Region_Estonia, Region_Spain,
      Region_Finland, Region_France, Region_Greece, Region_Croatia,
      Region_Ireland, Region_Italy, Region_Lithuania, Region_Luxembourg,
      Region_Latvia, Region_Portugal, Region_Slovenia, Region_Slovakia,
      Region_Cyprus, Region_Malta
    )
  ) %>%
  select(-all_of(region_columns))

# Impute missing regions using country-specific mode
space_data <- space_data %>%
  group_by(Country) %>%
  mutate(DEM_Region = if_else(
    is.na(DEM_Region),
    names(sort(table(DEM_Region), decreasing = TRUE))[1],
    DEM_Region
  )) %>%
  ungroup()

# Convert relevant region/mapping vars to factor
diary_region_vars <- c(
  "DuringDiary_CashWithdrawal", "DuringDiary_ReceivedCash", "DuringDiary_PaymentPOS",
  "DuringDiary_PickupPayment", "DuringDiary_CourierPayment", "DuringDiary_P2PPayment",
  "DuringDiary_OnlinePayment", "DuringDiary_HomeServicePayment", "DEM_Region"
)

space_data <- space_data %>%
  mutate(across(all_of(diary_region_vars), as.factor))

# ------------------------------------------------------
# CLEANING: POS TRANSACTIONS
# ------------------------------------------------------

# POS Payment Variables: Rename, Encode, Clean
space_data <- space_data %>%
  rename_with(
    .fn = ~ str_replace_all(., "QA5A_", "POS_Amount_") %>%
      str_replace_all("QA6A_", "POS_Location_") %>%
      str_replace_all("QA7A_", "POS_PaymentInstrument_") %>%
      str_replace_all("QA8A_", "POS_NonCashAccepted_") %>%
      str_replace_all("QA8AI_", "POS_CashAccepted_")
  ) %>%
  
  mutate(
    across(starts_with("POS_Location_"), ~ case_when(
      . == 1 ~ "Supermarket",
      . == 2 ~ "Day-to-Day Shops",
      . == 3 ~ "Street Vendor/Market",
      . == 4 ~ "Durable Goods Shop",
      . == 5 ~ "Petrol Station",
      . == 6 ~ "Restaurant/Bar/Cafe",
      . == 7 ~ "Hotel",
      . == 8 ~ "Culture/Sports/Entertainment",
      . == 9 ~ "Vending Machine/Ticketing",
      . == 10 ~ "Services Outside Home",
      . == 11 ~ "Services Inside Home",
      . == 12 ~ "Public Authority/Post Office",
      . == 13 ~ "Charity",
      . == 14 ~ "Private Payment",
      . == 15 ~ "Other Physical Location",
      . == 16 ~ "Pick-up Station",
      TRUE ~ encode_response(.)
    )),
    
    across(starts_with("POS_PaymentInstrument_"), ~ case_when(
      . == 1 ~ "Cash",
      . == 3 ~ "Mobile/Smartwatch Payment",
      . == 4 ~ "Bank Cheque",
      . == 5 ~ "Credit Transfer",
      . == 6 ~ "Loyalty Points/Gift Cards",
      . == 7 ~ "Other",
      . == 8 ~ "Prepaid Card",
      . == 9 ~ "Direct Debit",
      . == 10 ~ "Physical Card",
      TRUE ~ encode_response(.)
    )),
    
    across(c(starts_with("POS_NonCashAccepted_"), starts_with("POS_CashAccepted_")),
           ~ encode_response(.)),
    
    across(starts_with("POS_Amount_"), ~ replace(., . %in% bad_codes, NA))
  )

# ------------------------------------------------------
# TEMPERARY SAVING
# ------------------------------------------------------

# Create object with % missing per variable
missing_summary <- space_data %>%
  summarise(across(everything(), ~ mean(is.na(.)) * 100)) %>%
  pivot_longer(cols = everything(), names_to = "Variable", values_to = "Missing_Percent") %>%
  arrange(desc(Missing_Percent))

str(space_data)

# Save interim version of cleaned data
fwrite(space_data, "Data/SPACE_Data_AfterSelection.csv")

# ------------------------------------------------------
# TRANSFORM: WIDE TO LONG (TRANSACTION DATA)
# ------------------------------------------------------
# Based on 8 POS transactions per person.
# Result: One row per transaction. Empty rows are dropped.
# Load the dataset after initial selection and cleaning
space_data <- fread("Data/SPACE_Data_AfterSelection.csv")

# Reshape POS transactions
reshape_transactions_full <- function(df, type) {
  bind_rows(lapply(1:8, function(i) {
    df %>%
      mutate(
        Amount = .[[paste0(type, "_Amount_", i)]],
        Location = .[[paste0(type, "_Location_", i)]],
        PaymentInstrument = .[[paste0(type, "_PaymentInstrument_", i)]],
        NonCashAccepted = .[[paste0(type, "_NonCashAccepted_", i)]],
        CashAccepted = .[[paste0(type, "_CashAccepted_", i)]],
      ) %>%
      select(-starts_with(paste0(type, "_Amount_")),
             -starts_with(paste0(type, "_Location_")),
             -starts_with(paste0(type, "_PaymentInstrument_")),
             -starts_with(paste0(type, "_NonCashAccepted_")),
             -starts_with(paste0(type, "_CashAccepted_"))
      )
  }))
}

# Apply reshaping
transactions_long <- reshape_transactions_full(space_data, "POS")

space_data <- space_data %>%
  select(-matches("POS_.*_[1-8]$"))


# Keep only non-empty transactions
transactions_long <- transactions_long %>%
  filter(!is.na(Amount))

# Rename for consistency
transactions_long <- transactions_long %>%
  rename(
    Transaction_Amount = Amount,
    Transaction_Location = Location,
    Transaction_PaymentInstrument = PaymentInstrument,
    Transaction_NonCashAccepted = NonCashAccepted,
    Transaction_CashAccepted = CashAccepted
  )

# Derive InstrumentChoiceAvailable
transactions_long <- transactions_long %>%
  mutate(
    Transaction_InstrumentChoiceAvailable = case_when(
      Transaction_PaymentInstrument == "Cash" & Transaction_NonCashAccepted == "Yes" ~ "Yes",
      Transaction_PaymentInstrument == "Cash" & Transaction_NonCashAccepted == "No" ~ "No",
      Transaction_PaymentInstrument != "Cash" & Transaction_CashAccepted == "Yes" ~ "Yes",
      Transaction_PaymentInstrument != "Cash" & Transaction_CashAccepted == "No" ~ "No",
      TRUE ~ NA_character_
    )
  ) %>%
  # Drop unused acceptance variables
  select(-Transaction_NonCashAccepted, -Transaction_CashAccepted)

# Remove invalid rows
data_POS <- transactions_long %>%
  filter(!is.na(Transaction_PaymentInstrument))

# Drop unused variable with too many missings
data_POS <- data_POS %>% select(-Survey_Month)

# Convert empty strings to NA in character/factor columns
data_POS <- data_POS %>%
  mutate(across(where(is.character), ~ na_if(., ""))) %>%
  mutate(across(where(is.factor),    ~ na_if(as.character(.), "")))
data_POS <- data_POS %>%
  filter(!is.na(Transaction_PaymentInstrument))

# Apply KNN imputation
data_POS <- kNN(data_POS,
                variable = c("Transaction_InstrumentChoiceAvailable", "Transaction_Location"),
                k = 5,
                imp_var = FALSE)

# Convert transaction vars to factors (except amount)
transaction_vars <- names(data_POS)[grepl("^Transaction_", names(data_POS))]
factor_vars <- setdiff(transaction_vars, "Transaction_Amount")

data_POS <- data_POS %>%
  mutate(across(all_of(factor_vars), as.factor))

# Define the variables that should remain numeric
numeric_vars <- c("ID", "CASH_StartingAmount", "Gross_weight", "Transaction_Amount")

# Get all variable names in the dataset
all_vars <- names(data_POS)

# Identify variables that should be converted to factors
factor_vars <- setdiff(all_vars, numeric_vars)

# Convert selected variables to factors
data_POS <- data_POS %>%
  mutate(across(all_of(factor_vars), as.factor))


# ------------------------------------------------------
# SUMMARY CHECKS
# ------------------------------------------------------

# Missingness summary
missing_summary <- data_POS %>%
  summarise(across(everything(), ~ mean(is.na(.)) * 100)) %>%
  pivot_longer(cols = everything(), names_to = "Variable", values_to = "MissingPercent")

print(missing_summary)

# Variable type summary
type_summary <- tibble(
  Variable = names(data_POS),
  Class = sapply(data_POS, function(x) class(x)[1])
) 
  

print(type_summary)

# ------------------------------------------------------
# SAVE CLEANED POS DATA
# ------------------------------------------------------

# Save in same folder as raw data
fwrite(data_POS, file = file.path("Data", "POS_Data_Long_Clean.csv"))

# ------------------------------------------------------
# SAVE FINAL POS DATA (RESTRICTED PAYMENT CATEGORIES)
# ------------------------------------------------------

# Load previously cleaned long POS data
data_POS <- fread("Data/POS_Data_Long_Clean.csv")

# Recode payment instruments into four main categories
data_POS <- data_POS %>%
  mutate(Transaction_PaymentInstrument = case_when(
    Transaction_PaymentInstrument == "Cash" ~ "Cash",
    Transaction_PaymentInstrument %in% c("Physical Card", "Prepaid Card") ~ "Card",
    Transaction_PaymentInstrument == "Mobile/Smartwatch Payment" ~ "Mobile",
    Transaction_PaymentInstrument %in% c("Credit Transfer", "Direct Debit") ~ "BankTransfer",
    TRUE ~ "Other"
  )) %>%
  # Remove observations not classified into the four main categories
  filter(Transaction_PaymentInstrument != "Other") %>%
  # Set as factor with correct order (Cash as reference)
  mutate(Transaction_PaymentInstrument = factor(
    Transaction_PaymentInstrument,
    levels = c("Cash", "Card", "Mobile", "BankTransfer")
  ))

# Save as final version for analysis
fwrite(data_POS, file = "Data/POS_Final_Data.csv")

# Optional: clear entire environment to free up memory
rm(list = ls())
gc()

# ------------------------------------------------------
# CHAPTER 3 – DESCRIPTIVE GRAPHS & TABLES (DATA SECTION)
# ------------------------------------------------------
# Notes:
# - This section contains summary tables and graphs for Chapter 3.
# - Only final graphs are saved to the /Figures/ folder for the thesis.

# Load final POS dataset
data_POS <- fread("Data/POS_Final_Data.csv")
# Define the variables that should remain numeric
numeric_vars <- c("ID", "CASH_StartingAmount", "Gross_weight", "Transaction_Amount")

# Get all variable names in the dataset
all_vars <- names(data_POS)

# Identify variables that should be converted to factors
factor_vars <- setdiff(all_vars, numeric_vars)

# Convert selected variables to factors
data_POS <- data_POS %>%
  mutate(across(all_of(factor_vars), as.factor))
str(data_POS)
# dimentional checks
nrow(data_POS)
ncol(data_POS)
length(unique(data_POS$ID))

# ---------
# GRAPH: Share of POS Payment Instruments (Pie Chart)
# Calculate distribution of grouped payment instruments
grouped_distribution <- data_POS %>%
  count(Transaction_PaymentInstrument) %>%
  mutate(
    Transaction_PaymentInstrument = factor(Transaction_PaymentInstrument,
                                           levels = c("Cash", "Card", "Mobile", "BankTransfer")),
    Percentage = 100 * n / sum(n),
    Label = paste0(Transaction_PaymentInstrument, " (", round(Percentage, 1), "%)")
  )

# Create pie chart
graph_payment_method_distribution <- ggplot(grouped_distribution, aes(x = "", y = Percentage, fill = Label)) +
  geom_col(width = 1, color = "white", size = 0.2) +
  coord_polar(theta = "y", start = 0) +
  labs(x = NULL, y = NULL, fill = "Payment Instrument") +
  theme_void(base_family = "Times New Roman", base_size = 14) +
  theme(
    legend.position = "right",
    plot.margin = margin(0, 5, 0, 5, "mm")
  ) +
  guides(fill = guide_legend(override.aes = list(alpha = 1)))

# Save to thesis folder
ggsave(
  filename = "Figures and Tables/graph_payment_method_distribution.png",
  plot = graph_payment_method_distribution,
  width = 16, height = 5, units = "cm", dpi = 300, bg = "white"
)

# ---------
# GRAPH: Age on Payment Instrument
# Create the plot object
payment_plot <- data_POS %>%
  count(DEM_Age, Transaction_PaymentInstrument) %>%
  group_by(DEM_Age) %>%
  mutate(percentage = 100 * n / sum(n)) %>%
  ungroup() %>%
  mutate(
    DEM_Age = factor(DEM_Age, levels = c(
      "18–24", "25–29", "30–34", "35–39", "40–44", 
      "45–49", "50–54", "55–59", "60–64", "65–69", 
      "70–74", "75+"
    )),
    Transaction_PaymentInstrument = factor(Transaction_PaymentInstrument, levels = c(
      "Mobile", "BankTransfer", "Card", "Cash"
    ))
  ) %>%
  ggplot(aes(x = DEM_Age, y = percentage, fill = Transaction_PaymentInstrument)) +
  geom_col() +
  labs(
    x = "Age Group",
    y = "Share of Transactions",
    fill = "Payment Instrument"
  ) +
  theme_minimal(base_family = "Times New Roman", base_size = 12) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right"
  )

# Save the plot
ggsave(
  filename = "Figures and Tables/payment_method_by_agegroup.png",
  plot = payment_plot,
  width = 16, height = 5.5, units = "cm", dpi = 300, bg = "white"
)

# ---------
# GRAPH: Overall Distribution of POS Transaction Amounts
# Summary statistics (not printed, just stored)
amount_summary <- data_POS %>%
  summarise(
    count = n(),
    mean = round(mean(Transaction_Amount, na.rm = TRUE), 2),
    median = round(median(Transaction_Amount, na.rm = TRUE), 2),
    sd = round(sd(Transaction_Amount, na.rm = TRUE), 2),
    min = round(min(Transaction_Amount, na.rm = TRUE), 2),
    max = round(max(Transaction_Amount, na.rm = TRUE), 2)
  )

# Count of transactions per person (also stored only)
summary_transactions_overall <- data_POS %>%
  count(ID, name = "Transaction_Count") %>%
  summarise(
    Respondents = n(),
    Mean = round(mean(Transaction_Count), 2),
    Median = round(median(Transaction_Count), 2),
    SD = round(sd(Transaction_Count), 2),
    Min = min(Transaction_Count),
    Max = max(Transaction_Count)
  )

# Log-transform transaction amounts
data_POS <- data_POS %>%
  mutate(Transaction_Amount_log = log(Transaction_Amount + 1))

# Create histogram (original and log-scale)
fig_original <- ggplot(data_POS, aes(x = Transaction_Amount)) +
  geom_histogram(bins = 50, fill = "lightblue", color = "black", size = 0.2) +
  labs(x = "Transaction Amount (€)", y = "Count") +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
  )

fig_log <- ggplot(data_POS, aes(x = Transaction_Amount)) +
  geom_histogram(bins = 50, fill = "lightblue", color = "black", size = 0.2) +
  scale_x_log10(
    breaks = 10^(-1:5),
    labels = function(x) parse(text = paste0("10^", log10(x)))
  ) +
  labs(x = expression("Transaction Amount (€)"), y = "Count") +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
  )

# Combine the plots side-by-side
graph_transaction_amount_distribution <- fig_original + fig_log + plot_layout(ncol = 2)

# Save final figure
ggsave(
  filename = "Figures and Tables/graph_transaction_amount_distribution.png",
  plot = graph_transaction_amount_distribution,
  width = 20, height = 6, units = "cm", dpi = 300, bg = "white"
)

# ---------
# GRAPH: POS Transaction Amounts by Payment Instrument
# Create a grouped summary of transaction statistics by payment method
summary_by_grouped <- data_POS %>%
  group_by(Transaction_PaymentInstrument) %>%
  summarise(
    Count = n(),
    Mean = round(mean(Transaction_Amount, na.rm = TRUE), 2),
    Median = round(median(Transaction_Amount, na.rm = TRUE), 2),
    SD = round(sd(Transaction_Amount, na.rm = TRUE), 2),
    Min = round(min(Transaction_Amount, na.rm = TRUE), 2),
    Max = round(max(Transaction_Amount, na.rm = TRUE), 2)
  ) %>%
  arrange(factor(Transaction_PaymentInstrument, levels = c("Cash", "Card", "Mobile", "BankTransfer")))

# Create helper function to generate log-transformed histograms
make_log_histogram <- function(data, title) {
  mean_value <- mean(data$Transaction_Amount, na.rm = TRUE)
  
  ggplot(data, aes(x = Transaction_Amount)) +
    geom_histogram(bins = 50, fill = "lightblue", color = "black", size = 0.2) +
    geom_vline(xintercept = mean_value, color = "darkblue", linetype = "solid", linewidth = 0.8) +
    scale_x_log10(
      limits = c(0.1, 10000),
      breaks = 10^(-1:4),
      labels = function(x) parse(text = paste0("10^", log10(x)))
    ) +
    labs(title = title, x = expression("Transaction Amount (€)"), y = "Count") +
    theme_minimal(base_family = "Times New Roman", base_size = 14) +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      plot.title = element_text(face = "bold", hjust = 0.5, size = 13)
    )
}

# Create individual log-scale histograms by payment instrument
fig_cash   <- make_log_histogram(filter(data_POS, Transaction_PaymentInstrument == "Cash"), "Cash")
fig_card   <- make_log_histogram(filter(data_POS, Transaction_PaymentInstrument == "Card"), "Card")
fig_mobile <- make_log_histogram(filter(data_POS, Transaction_PaymentInstrument == "Mobile"), "Mobile")
fig_bank   <- make_log_histogram(filter(data_POS, Transaction_PaymentInstrument == "BankTransfer"), "Bank Transfer")

# Combine into one figure layout
graph_amount_distribution_by_payment <- (fig_cash | fig_card) / (fig_mobile | fig_bank)

# Save the combined figure
ggsave(
  filename = "Figures and Tables/graph_amount_distribution_by_payment.png",
  plot = graph_amount_distribution_by_payment,
  width = 20, height = 14, units = "cm", dpi = 300, bg = "white"
)

# ---------
# GRAPH: Distribution of POS Transactions by Location
# Calculate distribution of POS transactions by shopping location (in %)
location_distribution <- data_POS %>%
  count(Transaction_Location) %>%
  mutate(Percentage = 100 * n / sum(n))

# Create bar chart of transaction distribution by location
graph_transaction_share_by_location <- ggplot(location_distribution, aes(x = reorder(Transaction_Location, -Percentage), y = Percentage)) +
  geom_col(fill = "lightblue", color = "black", size = 0.2) +
  coord_flip() +
  labs(
    x = "Transaction Location",
    y = "Percentage of Transactions"
  ) +
  theme_minimal(base_family = "Times New Roman") +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
  )

# Save the plot
ggsave(
  filename = "Figures and Tables/graph_transaction_share_by_location.png",
  plot = graph_transaction_share_by_location,
  width = 16, height = 7, units = "cm", dpi = 300, bg = "white"
)

# SUMMARY: POS Transaction Amounts by Location
location_summary <- data_POS %>%
  group_by(Transaction_Location) %>%
  summarise(
    Count = n(),
    Mean = round(mean(Transaction_Amount, na.rm = TRUE), 2),
    Median = round(median(Transaction_Amount, na.rm = TRUE), 2),
    SD = round(sd(Transaction_Amount, na.rm = TRUE), 2),
    Min = round(min(Transaction_Amount, na.rm = TRUE), 2),
    Max = round(max(Transaction_Amount, na.rm = TRUE), 2)
  ) %>%
  arrange(desc(Count))

# SUMMARY: POS Transaction Amounts by Country
country_summary <- data_POS %>%
  group_by(Country) %>%
  summarise(
    Count = n(),
    Mean = round(mean(Transaction_Amount, na.rm = TRUE), 2),
    Median = round(median(Transaction_Amount, na.rm = TRUE), 2),
    SD = round(sd(Transaction_Amount, na.rm = TRUE), 2),
    Min = round(min(Transaction_Amount, na.rm = TRUE), 2),
    Max = round(max(Transaction_Amount, na.rm = TRUE), 2)
  ) %>%
  arrange(desc(Count))

# SUMMARY: POS Transaction Amounts by AGE group
AGE_summary <- data_POS %>%
  group_by(DEM_Age) %>%
  summarise(
    count = n(),
    mean = round(mean(Transaction_Amount, na.rm = TRUE), 5),
    median = round(median(Transaction_Amount, na.rm = TRUE), 5),
    sd = round(sd(Transaction_Amount, na.rm = TRUE), 5),
    min = round(min(Transaction_Amount, na.rm = TRUE), 5),
    max = round(max(Transaction_Amount, na.rm = TRUE), 7)
  ) %>%
  arrange(desc(count))

# ---------
# MAP: Countries in the SPACE Dataset vs Other Countries


# Load map of Europe
europe_map <- ne_countries(scale = "medium", returnclass = "sf") %>%
  filter(region_un == "Europe")

# Identify countries present in your dataset
space_countries <- unique(data_POS$Country)

# Eurozone countries not in your dataset
euro_not_space <- c("Netherlands", "Germany")

# Create fill categories for map
europe_map$fill_category <- case_when(
  europe_map$name %in% space_countries ~ "Euro area (in SPACE dataset)",
  europe_map$name %in% euro_not_space ~ "Euro area (not in SPACE dataset)",
  TRUE ~ "Other"
)

# Order of fill categories
europe_map$fill_category <- factor(
  europe_map$fill_category,
  levels = c("Euro area (in SPACE dataset)", 
             "Euro area (not in SPACE dataset)", 
             "Other")
)

# Create figure
graph_map_dataset_coverage <- ggplot(data = europe_map) +
  geom_sf(aes(fill = fill_category), color = "black", size = 0.1) +
  scale_fill_manual(
    values = c(
      "Euro area (in SPACE dataset)" = "lightblue",
      "Euro area (not in SPACE dataset)" = "grey70",
      "Other" = "white"
    ),
    name = NULL
  ) +
  labs(x = NULL, y = NULL) +
  coord_sf(xlim = c(-10, 30), ylim = c(34, 70)) +
  theme_minimal(base_family = "Times New Roman") +
  theme(
    axis.text = element_blank(),
    panel.grid = element_blank(),
    legend.position = "right",
    legend.text = element_text(size = 10)
  )

# Save figure
ggsave(
  filename = "Figures and Tables/graph_map_dataset_coverage.png",
  plot = graph_map_dataset_coverage,
  width = 16, height = 8, units = "cm", dpi = 400, bg = "white"
)



# ======================================================
# ==================== CHAPTER 5 =======================
# ================ ANALYSIS SECTION ====================
# ======================================================

# Clear the entire environment
rm(list = ls())
gc()

# Load the final cleaned dataset
data_POS <- fread("Data/POS_Final_Data.csv")

# Define the variables that should remain numeric
numeric_vars <- c("ID", "CASH_StartingAmount", "Gross_weight", "Transaction_Amount")

# Retrieve all variable names
all_vars <- names(data_POS)

# Identify variables that should be converted to factors
factor_vars <- setdiff(all_vars, numeric_vars)

# Convert relevant columns to factors
data_POS <- data_POS %>%
  mutate(across(all_of(factor_vars), as.factor))

# Check structure to verify types
str(data_POS)

# Set 'Cash' as the reference category for Transaction_PaymentInstrument
data_POS$Transaction_PaymentInstrument <- factor(
  data_POS$Transaction_PaymentInstrument,
  levels = c("Cash", "Card", "Mobile", "BankTransfer")
)

# ------------------------------------------------------
# OBJECTS AND FUNCTIONS
# ------------------------------------------------------

# Define a standard list of control variables used in models and tables
standard_controls <- c(
  "Country",
  "Transaction_Location",
  "Transaction_InstrumentChoiceAvailable",
  "DEM_Age",
  "DEM_Income",
  "DEM_Gender",
  "DEM_HouseholdSize",
  "DEM_ActivityStatus"
)

# ---------
# FUNCTION: CHECK OLS ASSUMPTIONS 
check_ols_assumptions <- function(model, model_name, save_path) {
  # Residuals vs Fitted
  diagnostics_df <- data.frame(
    fitted = fitted(model),
    residuals = resid(model)
  )
  
  fig_resid <- ggplot(diagnostics_df, aes(x = fitted, y = residuals)) +
    geom_point(alpha = 0.3, shape = 1, size = 0.7) +
    geom_hline(yintercept = 0, color = "blue", linewidth = 0.4) +
    labs(x = "Fitted values", y = "Residuals") +
    theme_minimal(base_family = "Times New Roman") +
    theme(
      axis.text = element_text(size = 8),
      axis.title = element_text(size = 8),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      plot.margin = margin(t = 0, r = 4, b = 0, l = 4)
    )
  # Q-Q Plot
  resid_df <- data.frame(resid = resid(model))
  
  fig_qq <- ggplot(resid_df, aes(sample = resid)) +
    stat_qq(shape = 1, alpha = 0.3, size = 0.7) +
    stat_qq_line(color = "blue", linewidth = 0.4) +
    labs(x = "Theoretical Quantiles", y = "Sample Quantiles") +
    theme_minimal(base_family = "Times New Roman") +
    theme(
      axis.text = element_text(size = 8),
      axis.title = element_text(size = 8),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      plot.margin = margin(t = 0, r = 4, b = 0, l = 4)
    )
  # Combine side-by-side (no title!)
  combined_fig <- (fig_resid + fig_qq) +
    patchwork::plot_layout(ncol = 2)
  # Save without plot title, height = 3 cm
  ggsave(
    filename = file.path(save_path, paste0(model_name, "_Assumptions.png")),
    plot = combined_fig,
    width = 16, height = 3, units = "cm", dpi = 300, bg = "white"
  )
  return(combined_fig)
}

# ------------------------------------------------------
# HYPOTHESIS 1A. SIMPLE ASSOCIATION 
# ------------------------------------------------------

# Model 1: No controls
h1a_model_1_no_controls <- lm(
  log(Transaction_Amount) ~ Transaction_PaymentInstrument, data = data_POS)
h1a_model_1_no_controls_clustered <- coeftest(
  h1a_model_1_no_controls, vcov = vcovCL(h1a_model_1_no_controls, cluster = ~ID))
summary(h1a_model_1_no_controls)$r.squared

fig_h1a_model_1_no_controls <- check_ols_assumptions(
  model = h1a_model_1_no_controls, model_name = "h1a_model_1_no_controls", 
  save_path = "Figures and Tables")

# Model 2: With contextual and demographic controls
h1a_model_2_standard_controls <- lm(
  formula = reformulate(c("Transaction_PaymentInstrument", standard_controls), response = "log(Transaction_Amount)"),
  data = data_POS)
h1a_model_2_standard_controls_clustered <- coeftest(
  h1a_model_2_standard_controls, vcov = vcovCL(h1a_model_2_standard_controls, cluster = ~ID))
summary(h1a_model_2_standard_controls)$r.squared

fig_h1a_model_2_standard_controls <- check_ols_assumptions(
  model = h1a_model_2_standard_controls, model_name = "h1a_model_2_standard_controls", 
  save_path = "Figures and Tables")
vif_values_h1a_model_2 <- vif(h1a_model_2_standard_controls)

# Model 3: Extensive controls (full model)
h1a_model_3_extensive_controls <- lm(log(Transaction_Amount) ~ . - ID, data = data_POS)
h1a_model_3_extensive_controls_clustered <- coeftest(
  h1a_model_3_extensive_controls, vcov = vcovCL(h1a_model_3_extensive_controls, cluster = ~ID))
summary(h1a_model_3_extensive_controls)$r.squared

fig_h1a_model_3_extensive_controls <- check_ols_assumptions(
  model = h1a_model_3_extensive_controls, model_name = "h1a_model_3_extensive_controls", 
  save_path = "Figures and Tables")

# REGRESSION TABLE: H1a
models_h1a <- list(
  "Model 1: No Controls" = h1a_model_1_no_controls,
  "Model 2: + Standard Controls" = h1a_model_2_standard_controls,
  "Model 3: + Extensive Controls" = h1a_model_3_extensive_controls
)

vcovs_h1a <- lapply(models_h1a, function(m) vcovCL(m, cluster = ~ID))

ft_h1a <- modelsummary(
  models = models_h1a,
  vcov = vcovs_h1a,
  statistic = "std.error",
  stars = TRUE,
  gof_omit = "IC|Log|F|RMSE",
  output = "flextable"
) |>
  fontsize(size = 10, part = "all") |>
  autofit()

save_as_docx(ft_h1a, path = file.path("Figures and Tables", "Table_H1a.docx"))


# ---------
# Simple Model Ordinal Scale
# Create salience score (4 = most salient, 1 = least salient)
data_POS$salience_score <- case_when(
  data_POS$Transaction_PaymentInstrument == "BankTransfer" ~ 1,
  data_POS$Transaction_PaymentInstrument == "Mobile" ~ 2,
  data_POS$Transaction_PaymentInstrument == "Card" ~ 3,
  data_POS$Transaction_PaymentInstrument == "Cash" ~ 4
)
# Create ordered factor version (optional)
data_POS$payment_ordered <- factor(
  data_POS$Transaction_PaymentInstrument,
  levels = c("Cash", "Card", "Mobile", "BankTransfer"),
  ordered = TRUE
)

# Model 1: No controls
h1a_ord_model_1 <- lm(
  log(Transaction_Amount) ~ salience_score,
  data = data_POS)
h1a_ord_model_1_clustered <- coeftest(
  h1a_ord_model_1, vcov = vcovCL(h1a_ord_model_1, cluster = ~ID))
# Model 2: With standard contextual and demographic controls
h1a_ord_model_2 <- lm(
  formula = reformulate(c("salience_score", standard_controls), response = "log(Transaction_Amount)"),
  data = data_POS)
h1a_ord_model_2_clustered <- coeftest(
  h1a_ord_model_2, vcov = vcovCL(h1a_ord_model_2, cluster = ~ID))
# Model 3: With extensive controls
h1a_ord_model_3 <- lm(
  log(Transaction_Amount) ~ . - ID - Transaction_PaymentInstrument,
  data = data_POS)
h1a_ord_model_3_clustered <- coeftest(
  h1a_ord_model_3, vcov = vcovCL(h1a_ord_model_3, cluster = ~ID))
summary(h1a_ord_model_3)$r.squared
# Combine models in a list
models_h1a_ordinal <- list(
  "Model 1: No Controls" = h1a_ord_model_1,
  "Model 2: + Standard Controls" = h1a_ord_model_2,
  "Model 3: + Extensive Controls" = h1a_ord_model_3
)
# Clustered standard errors
vcovs_h1a_ordinal <- lapply(models_h1a_ordinal, function(m) vcovCL(m, cluster = ~ID))
# Create regression table
ft_h1a_ordinal <- modelsummary(
  models = models_h1a_ordinal,
  vcov = vcovs_h1a_ordinal,
  statistic = "std.error",
  stars = TRUE,
  gof_omit = "IC|Log|F|RMSE",
  output = "flextable"
) |>
  fontsize(size = 10, part = "all") |>
  autofit()
# Save table
save_as_docx(ft_h1a_ordinal, path = file.path("Figures and Tables", "Table_H1a_ordinal.docx"))

# OLS assumption checks
fig_h1a_ord_model_1 <- check_ols_assumptions(
  model = h1a_ord_model_1,
  model_name = "h1a_ord_model_1",
  save_path = "Figures and Tables"
)
fig_h1a_ord_model_2 <- check_ols_assumptions(
  model = h1a_ord_model_2,
  model_name = "h1a_ord_model_2",
  save_path = "Figures and Tables"
)
fig_h1a_ord_model_3 <- check_ols_assumptions(
  model = h1a_ord_model_3,
  model_name = "h1a_ord_model_3",
  save_path = "Figures and Tables"
)

# ------------------------------------------------------
# H1B: MODEL-BASED RECURSIVE PARTITIONING 
# ------------------------------------------------------
# ---------
# RUNNING THE MOB MODELS 

# MOB Model 1: All Variables
# Variables to include in splitting
split_vars_2 <- setdiff(names(data_POS), c("Transaction_Amount", "Transaction_PaymentInstrument", "ID", 
                                           "Field", "Language", "CASH_StartingAmount"))
# Define MOB formula
mob_formula_all_vars <- as.formula(paste(
  "log(Transaction_Amount) ~ Transaction_PaymentInstrument |",
  paste(split_vars_2, collapse = " + ")
))
# Estimate MOB model
mob_model_all_vars <- lmtree(
  formula = mob_formula_all_vars, data = data_POS, 
  minsize = 150, alpha = 0.01, bonferroni = TRUE, maxdepth = 3)
# Save model output
saveRDS(mob_model_all_vars, file = file.path("Data", "MOB_Model_All_Vars.rds"))


# MOB Model 2: Standard Controls
# Define MOB formula
mob_formula_standard_controls <- log(Transaction_Amount) ~ Transaction_PaymentInstrument |
  Country + Transaction_Location + Transaction_InstrumentChoiceAvailable + 
  DEM_Age + DEM_Income + DEM_Gender + DEM_HouseholdSize + DEM_ActivityStatus
# Estimate MOB model
mob_model_standard_controls <- lmtree(
  formula = mob_formula_standard_controls, data = data_POS, 
  minsize = 150, alpha = 0.01, bonferroni = TRUE, maxdepth = 3)
# Save model output
saveRDS(mob_model_standard_controls, file = file.path("Data", "MOB_Model_Standard_Controls.rds"))


# MOB Model 3: Demographics Only
split_vars_mob_demographics <- c(
  "DEM_Age", "DEM_Education", "DEM_Income", "DEM_HouseholdSize",
  "DEM_Gender", "DEM_ActivityStatus", "OWN_Smartphone", "OWN_OnlineBanking", "Country")
# Define MOB formula
mob_formula_demographics <- as.formula(paste(
  "log(Transaction_Amount) ~ Transaction_PaymentInstrument |",
  paste(split_vars_mob_demographics, collapse = " + ")
))
# Estimate MOB model
mob_model_demographics <- lmtree(
  formula = mob_formula_demographics, data = data_POS,
  minsize = 150, alpha = 0.01, bonferroni = TRUE, maxdepth = 3)
# Save model output
saveRDS(mob_model_demographics, file = file.path("Data", "MOB_Model_Demographics.rds"))

# ---------
# GRAPHS FOR ALL MOB MODELS 
# FUNCTION: Shorten long labels for clean visualisation only
shorten_labels_readable <- function(model_obj) {
  short_names <- c(
    "Culture/Sports/Entertainment" = "Cult", "Durable Goods Shop" = "Dura",
    "Hotel" = "Hote", "Other Physical Location" = "Othe", "Petrol Station" = "Petr",
    "Pick-up Station" = "Pick", "Private Payment" = "Priv", "Public Authority/Post Office" = "Publ",
    "Charity" = "Char", "Day-to-Day Shops" = "Dail", "Restaurant/Bar/Cafe" = "Rest",
    "Street Vendor/Market" = "Mark", "Vending Machine/Ticketing" = "Vend", "Supermarket" = "Supe",
    "Services Inside Home" = "Home", "Services Outside Home" = "Outs"
  )
  country_codes <- c(
    "Austria" = "AT", "Belgium" = "BE", "Croatia" = "HR", "Cyprus" = "CY",
    "Estonia" = "EE", "Finland" = "FI", "France" = "FR", "Germany" = "DE",
    "Greece" = "GR", "Ireland" = "IE", "Italy" = "IT", "Latvia" = "LV",
    "Lithuania" = "LT", "Luxembourg" = "LU", "Malta" = "MT", "Portugal" = "PT",
    "Slovakia" = "SK", "Slovenia" = "SI", "Spain" = "ES"
  )
  if ("Transaction_Location" %in% names(model_obj$data)) {
    levels(model_obj$data$Transaction_Location) <- ifelse(
      levels(model_obj$data$Transaction_Location) %in% names(short_names),
      short_names[levels(model_obj$data$Transaction_Location)],
      levels(model_obj$data$Transaction_Location)
    )
  }
  if ("Country" %in% names(model_obj$data)) {
    levels(model_obj$data$Country) <- ifelse(
      levels(model_obj$data$Country) %in% names(country_codes),
      country_codes[levels(model_obj$data$Country)],
      levels(model_obj$data$Country)
    )
  }
  if ("Transaction_PaymentInstrument" %in% names(model_obj$data)) {
    levels(model_obj$data$Transaction_PaymentInstrument) <- c("Cash", "Card", "Mobile", "Bank")
  }
  return(model_obj)
}
# Variable label replacements for axis readability
create_var_labels <- function() {
  c("Transaction_Location" = "Transaction Location", "Country" = "Country")
}
# Paths
input_dir <- "Data"
output_dir <- "Figures and Tables"
# MOB models to plot
model_files <- list(
  "All_Vars" = "MOB_Model_All_Vars.rds",
  "Standard_Controls" = "MOB_Model_Standard_Controls.rds",
  "Demographics" = "MOB_Model_Demographics.rds"
)
# Loop over each model file
for (label in names(model_files)) {
  file <- model_files[[label]]
  path <- file.path(input_dir, file)
  if (!file.exists(path)) {
    message(paste0("File skipped (not found): ", file))
    next
  }
  # Load model and shorten labels
  model_obj <- readRDS(path)
  model_short <- shorten_labels_readable(model_obj)
  # Apply readable variable names
  var_labels <- create_var_labels()
  original_names <- names(model_short$data)
  temp_names <- original_names
  for (old_name in names(var_labels)) {
    temp_names[temp_names == old_name] <- var_labels[old_name]
  }
  names(model_short$data) <- temp_names
  # Save tree plot
  png(file.path(output_dir, paste0("MOB_", label, "_plot.png")),
      width = 3800, height = 1600, res = 175)
  plot(
    model_short,
    gp = gpar(fontsize = 18),
    ip_args = list(pval = FALSE, id = FALSE, fill = "white"),
    tp_args = list(fill = "lightgray", id = FALSE),
    ep_args = list(justmin = 25),
    tnex = 3.5
  )
  dev.off()
  names(model_short$data) <- original_names  # Restore original names
  message(paste0("MOB plot saved: MOB_", label, "_plot.png"))
}

#Boxplots
make_boxplot <- function(df, label) {
  # Rename only for plotting
  df$Transaction_PaymentInstrument <- factor(
    df$Transaction_PaymentInstrument,
    levels = c("Cash", "Card", "Mobile", "Bank transfer"),
    labels = c("Cash", "Card", "Mobile", "Bank")
  )
  ggplot(df, aes(x = Transaction_PaymentInstrument, y = Transaction_Amount)) +
    geom_boxplot(
      outlier.shape = NA, fill = "lightblue", color = "black", width = 0.6, size = 0.2
    ) +
    ggtitle(label) +
    scale_y_log10(
      breaks = 10^(0:3),
      labels = scales::trans_format("log10", scales::math_format(10^.x))
    ) +
    coord_cartesian(ylim = c(1, 1000)) +
    labs(x = NULL, y = NULL) +
    theme(
      axis.text.x = element_text(color = "black", size = 8),
      axis.text.y = element_text(color = "black", size = 8),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.background = element_blank(),
      panel.border = element_rect(color = "grey30", fill = NA, size = 0.2),
      plot.background = element_rect(fill = "white", color = NA),
      plot.title = element_text(
        family = "Times New Roman", size = 8, hjust = 0.5,
        margin = margin(b = 2)
      )
    )
}
# Grouping based on transaction location
location_group_1 <- c("Durable Goods Shop", "Hotel", "Petrol Station",
                      "Private Payment", "Public Authority/Post Office",
                      "Services Outside Home", "Services Inside Home")
location_group_2 <- c("Culture/Sports/Entertainment", "Other Physical Location",
                      "Pick-up Station", "Supermarket")
location_group_3_4 <- c("Charity", "Day-to-Day Shops", "Restaurant/Bar/Cafe",
                        "Street Vendor/Market", "Vending Machine/Ticketing")
country_group_3 <- c("Austria", "Belgium", "Cyprus", "Estonia", "Finland", "France",
                     "Ireland", "Lithuania", "Luxembourg", "Malta", "Slovakia")
country_group_4 <- c("Croatia", "Greece", "Italy", "Latvia", "Portugal", "Slovenia", "Spain")

# Assign location-country subgroups
data_POS <- data_POS %>%
  mutate(Subgroup_4cat = case_when(
    Transaction_Location %in% location_group_1 ~ "1_1",
    Transaction_Location %in% location_group_2 ~ "1_2",
    Transaction_Location %in% location_group_3_4 & Country %in% country_group_3 ~ "1_3",
    Transaction_Location %in% location_group_3_4 & Country %in% country_group_4 ~ "1_4",
    TRUE ~ NA_character_
  )) %>%
  filter(!is.na(Subgroup_4cat))  # Keep only grouped observations
# Grouping based on country only
country_split_1 <- c("Finland", "Luxembourg")
country_split_2 <- c("Austria", "Belgium", "Cyprus", "France", "Ireland", "Malta")
country_split_3 <- c("Estonia", "Greece", "Italy", "Latvia", "Lithuania", "Slovakia")
country_split_4 <- c("Croatia", "Portugal", "Slovenia", "Spain")
# Assign country-based subgroups
data_POS <- data_POS %>%
  mutate(Subgroup_4cat_countrySplit = case_when(
    Country %in% country_split_1 ~ "2_1",
    Country %in% country_split_2 ~ "2_2",
    Country %in% country_split_3 ~ "2_3",
    Country %in% country_split_4 ~ "2_4",
    TRUE ~ NA_character_
  )) %>%
  filter(!is.na(Subgroup_4cat_countrySplit))

# Generate and save patchwork boxplots by subgroup (ordered)
make_combined_boxplot_patchwork <- function(data, group_var, output_filename) {
  # Force specific order for known grouping variables
  group_codes <- switch(group_var,
                        "Subgroup_4cat" = c("1_1", "1_2", "1_3", "1_4"),
                        "Subgroup_4cat_countrySplit" = c("2_1", "2_2", "2_3", "2_4"),
                        sort(unique(na.omit(data[[group_var]])))  # fallback to sorted order
  )
  #️ Generate labels like "n = 17,921" for each group
  labels <- sapply(group_codes, function(code) {
    n <- nrow(data %>% filter(!!sym(group_var) == code))
    paste0("n = ", format(n, big.mark = ","))
  })
  # Create one boxplot per group
  plots <- Map(function(code, label) {
    df_sub <- data %>% filter(!!sym(group_var) == code)
    # Rename for consistent plotting
    df_sub <- df_sub %>%
      mutate(Payment_Grouped = factor(
        Transaction_PaymentInstrument,
        levels = c("Cash", "Card", "Mobile", "Bank transfer"),
        labels = c("Cash", "Card", "Mobile", "Bank")
      ))
    make_boxplot(df_sub, label)
  }, group_codes, labels)
  # Combine plots horizontally using patchwork
  combined_plot <- wrap_plots(plots, ncol = length(plots)) +
    plot_layout(guides = "collect") &
    theme(plot.margin = margin(0, 5, 0, 5))
  # Save the final combined plot to file
  ggsave(output_filename,
         plot = combined_plot,
         width = 18, height = 4.2, units = "cm",
         dpi = 300, bg = "white")
}

if ("Subgroup_4cat" %in% names(data_POS) && any(!is.na(data_POS$Subgroup_4cat))) {
  make_combined_boxplot_patchwork(
    data = data_POS,
    group_var = "Subgroup_4cat",
    output_filename = "Figures and Tables/Boxplot_LocationCountry_Subgroups.png"
  )
}
if ("Subgroup_4cat_countrySplit" %in% names(data_POS) && any(!is.na(data_POS$Subgroup_4cat_countrySplit))) {
  make_combined_boxplot_patchwork(
    data = data_POS,
    group_var = "Subgroup_4cat_countrySplit",
    output_filename = "Figures and Tables/Boxplot_CountryOnly_Subgroups.png"
  )
}

# ---------
# REGRESSIONS FOR ALL MOB MODELS 
# ---------
# REGRESSIONS FOR ALL MOB MODELs: Transaction location 
# Use already defined location groups (from earlier section)
groups3 <- list(location_group_1, location_group_2, location_group_3_4)
# Function to run models by group with standard controls
run_models_for_groups <- function(data, group_list, label_prefix = "Group") {
  models <- list()
  vcovs <- list()
  for (i in seq_along(group_list)) {
    subset_data <- data %>% filter(Transaction_Location %in% group_list[[i]])
    if (length(unique(subset_data$Transaction_PaymentInstrument)) < 2) {
      warning(paste("Group", i, "has insufficient variation in PaymentInstrument"))
      next
    }
    # Construct formula
    formula_group <- reformulate(
      termlabels = c(
        "Transaction_PaymentInstrument",
        "Country",
        "Transaction_InstrumentChoiceAvailable",
        "DEM_Age",
        "DEM_Income",
        "DEM_Gender",
        "DEM_HouseholdSize",
        "DEM_ActivityStatus"
      ),
      response = "log(Transaction_Amount)"
    )
    model <- lm(formula_group, data = subset_data)
    models[[paste0(label_prefix, " ", i)]] <- model
    vcovs[[i]] <- vcovCL(model, cluster = ~ID)
  }
  return(list(models = models, vcovs = vcovs))
}

# Export regression table
save_regression_table <- function(model_list, vcov_list, file_path) {
  # Calculate combined R-squared
  actual <- unlist(lapply(model_list, function(m) model.response(model.frame(m))))
  fitted <- unlist(lapply(model_list, function(m) fitted(m)))
  r2_combined <- 1 - sum((actual - fitted)^2) / sum((actual - mean(actual))^2)
  # Create flextable
  ft <- modelsummary(
    models = model_list,
    vcov = vcov_list,
    statistic = "std.error",
    stars = TRUE,
    output = "flextable"
  ) |>
    fontsize(size = 10, part = "all") |>
    autofit() |>
    add_footer_lines(values = sprintf("Combined R-squared across all groups: %.3f", r2_combined))
  
  save_as_docx(ft, path = file.path("Figures and Tables", "Table_H1b_MOB_Location.docx"))
}

# Run and save model table for group-specific regressions
results_groups <- run_models_for_groups(data_POS, groups3)
save_regression_table(results_groups$models, results_groups$vcovs, doc_path("Table_5_3_MOB_OLS_by_Group"))

#Assumption checks
fig_mob_group1_location <- check_ols_assumptions(
  model = results_groups$models[["Group 1"]],
  model_name = "MOB_Group_1_Location",
  save_path = "Figures and Tables"
)
fig_mob_group2_location <- check_ols_assumptions(
  model = results_groups$models[["Group 2"]],
  model_name = "MOB_Group_2_Location",
  save_path = "Figures and Tables"
)
fig_mob_group3_location <- check_ols_assumptions(
  model = results_groups$models[["Group 3"]],
  model_name = "MOB_Group_3_Location",
  save_path = "Figures and Tables"
)

# VIF CHECKS — LOCATION MODELS
vif_group1 <- vif(results_groups$models[["Group 1"]])
vif_group2 <- vif(results_groups$models[["Group 2"]])
vif_group3 <- vif(results_groups$models[["Group 3"]])

# Assign MOB_Group 
if (!"MOB_Group" %in% names(data_POS)) {
  data_POS$MOB_Group <- NA
  data_POS$MOB_Group[data_POS$Transaction_Location %in% location_group_1] <- "Group 1"
  data_POS$MOB_Group[data_POS$Transaction_Location %in% location_group_2] <- "Group 2"
  data_POS$MOB_Group[data_POS$Transaction_Location %in% location_group_3_4] <- "Group 3"
  data_POS$MOB_Group <- factor(data_POS$MOB_Group, levels = c("Group 1", "Group 2", "Group 3"))
}

# chi-squared test 
tbl_group_payment <- table(data_POS$MOB_Group, data_POS$Transaction_PaymentInstrument)
chi_test_result <- chisq.test(tbl_group_payment)
print(chi_test_result)

# ---------
# REGRESSIONS FOR ALL MOB MODELS: Country
# Use the four country splits defined earlier
groups_country <- list(country_split_1, country_split_2, country_split_3, country_split_4)
# Run OLS per country group with standard controls
run_country_models <- function(data, group_list, label_prefix = "Group") {
  models <- list()
  vcovs  <- list()
  for (i in seq_along(group_list)) {
    subset_data <- data %>% filter(Country %in% group_list[[i]])
    # Skip if no variation in the key regressor
    if (length(unique(subset_data$Transaction_PaymentInstrument)) < 2) {
      warning(paste("Country group", i, "has insufficient variation in PaymentInstrument"))
      next
    }
    # Build formula: PaymentInstrument + standard controls → log(Transaction_Amount)
    formula_group <- reformulate(
      termlabels = c(
        "Transaction_PaymentInstrument",
        "Transaction_Location",
        "Transaction_InstrumentChoiceAvailable",
        "DEM_Age",
        "DEM_Income",
        "DEM_Gender",
        "DEM_HouseholdSize",
        "DEM_ActivityStatus"
      ),
      response   = "log(Transaction_Amount)"
    )
    model <- lm(formula_group, data = subset_data)
    models[[paste0(label_prefix, " ", i)]] <- model
    vcovs[[i]] <- vcovCL(model, cluster = ~ ID)
  }
  list(models = models, vcovs = vcovs)
}
# Save regression table with combined R-squared in the footer
save_country_table <- function(model_list, vcov_list, file_path) {
  actual <- unlist(lapply(model_list, function(m) model.response(model.frame(m))))
  fitted <- unlist(lapply(model_list, function(m) fitted(m)))
  combined_r2 <- 1 - sum((actual - fitted)^2) / sum((actual - mean(actual))^2)
  ft <- modelsummary(
    models    = model_list,
    vcov      = vcov_list,
    statistic = "std.error",
    stars     = TRUE,
    output    = "flextable"
  ) |>
    fontsize(size = 10, part = "all") |>
    autofit() |>
    add_footer_lines(values = sprintf("Combined R-squared across all country groups: %.3f", combined_r2))
  save_as_docx(ft, path = file.path("Figures and Tables", "Table_H1b_MOB_Country.docx"))
}

# Run and export per-country-group regressions
results_country <- run_country_models(data_POS, groups_country)
save_country_table(
  results_country$models,
  results_country$vcovs,
  file_path = file.path("Figures and Tables", "Table_H1b_MOB_Country.docx")
)

# Create Country_Group 
if (!"Country_Group" %in% names(data_POS)) {
  data_POS$Country_Group <- NA_character_
  data_POS$Country_Group[data_POS$Country %in% country_split_1] <- "Group 1"
  data_POS$Country_Group[data_POS$Country %in% country_split_2] <- "Group 2"
  data_POS$Country_Group[data_POS$Country %in% country_split_3] <- "Group 3"
  data_POS$Country_Group[data_POS$Country %in% country_split_4] <- "Group 4"
  data_POS$Country_Group <- factor(data_POS$Country_Group,
                                   levels = c("Group 1", "Group 2", "Group 3", "Group 4"))
}

# Assumptions
fig_mob_country_group1 <- check_ols_assumptions(
  model      = results_country$models[["Group 1"]],
  model_name = "MOB_CountryGroup_1",
  save_path  = "Figures and Tables"
)
fig_mob_country_group2 <- check_ols_assumptions(
  model      = results_country$models[["Group 2"]],
  model_name = "MOB_CountryGroup_2",
  save_path  = "Figures and Tables"
)
fig_mob_country_group3 <- check_ols_assumptions(
  model      = results_country$models[["Group 3"]],
  model_name = "MOB_CountryGroup_3",
  save_path  = "Figures and Tables"
)
fig_mob_country_group4 <- check_ols_assumptions(
  model      = results_country$models[["Group 4"]],
  model_name = "MOB_CountryGroup_4",
  save_path  = "Figures and Tables"
)

# VIF CHECKS — COUNTRY MODELS
vif_country_group1 <- vif(results_country$models[["Group 1"]])
vif_country_group2 <- vif(results_country$models[["Group 2"]])
vif_country_group3 <- vif(results_country$models[["Group 3"]])
vif_country_group4 <- vif(results_country$models[["Group 4"]])

# chi-squared test 
tbl_country_payment <- table(data_POS$Country_Group, data_POS$Transaction_PaymentInstrument)
chi_country_test <- chisq.test(tbl_country_payment)
print(chi_country_test)

# ---------
# MAP BASED ON MOB Country
# Load and filter map of Europe
europe_map <- ne_countries(scale = "medium", returnclass = "sf") %>%
  filter(region_un == "Europe")
# Define MOB country groups
assign_country_group <- function(country) {
  if (country %in% c("Finland", "Luxembourg")) return("Group 1")
  if (country %in% c("Austria", "Belgium", "Cyprus", "France", "Ireland", "Malta")) return("Group 2")
  if (country %in% c("Estonia", "Greece", "Italy", "Latvia", "Lithuania", "Slovakia")) return("Group 3")
  if (country %in% c("Croatia", "Portugal", "Slovenia", "Spain")) return("Group 4")
  return(NA)
}
# Apply group assignment
europe_map$CountryGroup <- sapply(europe_map$name, assign_country_group)
europe_map$CountryGroup <- factor(europe_map$CountryGroup,
                                  levels = c("Group 1", "Group 2", "Group 3", "Group 4"))
# Plot the country group map
fig_group_map <- ggplot(data = europe_map) +
  geom_sf(aes(fill = CountryGroup), color = "black", linewidth = 0.15) +
  scale_fill_manual(
    values = c(
      "Group 1" = "#F8766D", "Group 2" = "#7CAE00", "Group 3" = "#00BFC4", "Group 4" = "#C77CFF"
    ),
    na.translate = FALSE
  ) +
  coord_sf(xlim = c(-10, 30), ylim = c(34, 70)) +
  theme_minimal() +
  theme(
    axis.text = element_blank(),
    axis.title = element_blank(),
    panel.grid = element_blank(),
    legend.title = element_blank()
  )

# Save the figure
ggsave(
  filename = file.path("Figures and Tables", "Figure_Country_Groups_Map.png"),
  plot = fig_group_map,
  width = 16, height = 9, units = "cm", dpi = 300, bg = "white"
)

# ------------------------------------------------------
# H1B: QUANTILE REGRESSION ANALYSIS
# ------------------------------------------------------
# Define quantiles and labels
quantiles <- c(0.25, 0.50, 0.75)
names_q <- paste0("Q", quantiles * 100)
# Regression formula
data_POS$log_Transaction_Amount <- log(data_POS$Transaction_Amount)
formula_qr <- log_Transaction_Amount ~ Transaction_PaymentInstrument + Country + Transaction_Location +
  Transaction_InstrumentChoiceAvailable + DEM_Age + DEM_Income +
  DEM_Gender + DEM_HouseholdSize + DEM_ActivityStatus
# Fit quantile regression models
qr_models <- lapply(quantiles, function(tau) rq(formula_qr, tau = tau, data = data_POS))
names(qr_models) <- names_q
# Extract tidy results per model and bind
qr_combined <- bind_rows(
  lapply(seq_along(qr_models), function(i) {
    tidy(qr_models[[i]]) |>
      filter(grepl("Transaction_PaymentInstrument", term)) |>
      mutate(
        Quantile = names_q[i],
        Method = gsub("Transaction_PaymentInstrument", "", term),
        Percent_Change = round((exp(estimate) - 1) * 100, 1),
        Stars = case_when(
          p.value < 0.001 ~ "***",
          p.value < 0.01  ~ "**",
          p.value < 0.05  ~ "*",
          p.value < 0.1   ~ ".",
          TRUE            ~ ""
        )
      ) |>
      select(Quantile, Method, estimate, std.error, Stars, Percent_Change)
  })
)
# Format for table
qr_table <- qr_combined |>
  rename(
    `Quantile (τ)`   = Quantile,
    `Payment Method` = Method,
    `β`              = estimate,
    `SE`             = std.error,
    `Significance`   = Stars,
    `%Δ`             = Percent_Change
  ) |>
  mutate(across(c(`β`, `SE`), ~ round(., 3)))

# Intercepts
qr_intercepts <- sapply(qr_models, function(model) {
  coefs <- coef(model)
  if ("(Intercept)" %in% names(coefs)) round(coefs["(Intercept)"], 3) else NA
})
# Pseudo R²
pseudo_r2 <- sapply(qr_models, function(model) {
  tau <- model$tau
  y <- model$model[[1]]
  rho_full <- sum(model$residuals * (tau - (model$residuals < 0)))
  intercept_model <- rq(y ~ 1, tau = tau)
  rho_intercept <- sum(intercept_model$residuals * (tau - (intercept_model$residuals < 0)))
  1 - (rho_full / rho_intercept)
})
# Observations (all models use same sample)
n_obs <- nrow(data_POS)
# Create text lines
intercepts_text <- paste0("Intercepts (β₀): Q25 = ", qr_intercepts[1],
                          ", Q50 = ", qr_intercepts[2],
                          ", Q75 = ", qr_intercepts[3])
r2_text <- paste0("Pseudo R² (τ): Q25 = ", round(pseudo_r2[1], 3),
                  ", Q50 = ", round(pseudo_r2[2], 3),
                  ", Q75 = ", round(pseudo_r2[3], 3))
obs_text <- paste0("Observations: ", format(n_obs, big.mark = ","))

# Export table as Word doc
ft_qr <- flextable(qr_table) |>
  autofit() |>
  fontsize(size = 10, part = "all") |>
  add_footer_lines(values = c(intercepts_text, r2_text, obs_text))
save_as_docx(ft_qr, path = file.path("Figures and Tables", "Table_5_2_Quantile_Regression.docx"))


# ------------------------------------------------------
# CORRESPONDENCE ANALYSIS
# ------------------------------------------------------
# ---------
# CORRESPONDENCE ANALYSIS: Country × Payment Method
# Filter and prepare data
ca_data_country <- data_POS %>%
  filter(
    !is.na(Country),
    !is.na(Transaction_PaymentInstrument),
    Transaction_PaymentInstrument != "Other"
  ) %>%
  mutate(Payment_Grouped = case_when(
    Transaction_PaymentInstrument == "Cash" ~ "Cash",
    Transaction_PaymentInstrument == "Card" ~ "Card",
    Transaction_PaymentInstrument == "Mobile" ~ "Mobile",
    Transaction_PaymentInstrument == "BankTransfer" ~ "Bank Transfer"
  )) %>%
  mutate(
    Country = factor(Country),
    Payment_Grouped = factor(Payment_Grouped)
  )
# Create contingency table
tab_country <- table(ca_data_country$Country, ca_data_country$Payment_Grouped)
# Perform CA
ca_country <- CA(tab_country, graph = FALSE)
# Extract dimension labels
dim1 <- paste0("Dim 1 (", round(ca_country$eig[1, 2], 1), "%)")
dim2 <- paste0("Dim 2 (", round(ca_country$eig[2, 2], 1), "%)")
# Country grouping function
assign_country_group <- function(country) {
  if (country %in% c("Finland", "Luxembourg")) return("Group 1")
  if (country %in% c("Austria", "Belgium", "Cyprus", "France", "Ireland", "Malta")) return("Group 2")
  if (country %in% c("Estonia", "Greece", "Italy", "Latvia", "Lithuania", "Slovakia")) return("Group 3")
  if (country %in% c("Croatia", "Portugal", "Slovenia", "Spain")) return("Group 4")
  return(NA)
}
# Assign country groups
country_groups <- sapply(rownames(ca_country$row$coord), assign_country_group)
# Define group colors
group_colors <- c("Group 1" = "#F8766D", "Group 2" = "#7CAE00", "Group 3" = "#00BFC4", "Group 4" = "#C77CFF")
# Map colors to countries
row_colors <- group_colors[country_groups]
# Create colored CA plot
graph_ca_country_colored <- fviz_ca_biplot(
  ca_country,
  repel = TRUE,
  col.row = row_colors,
  col.col = "black",
  arrows = c(TRUE, TRUE),
  label = "all"
) +
  scale_color_identity() +
  coord_fixed(ratio = 1) +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 10)) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 6)) +
  labs(x = dim1, y = dim2) +
  theme_minimal(base_family = "Times New Roman", base_size = 14) +
  theme(
    panel.grid.major = element_line(color = "grey93"),
    legend.position = "none"
  )

# Save colored plot
ggsave(
  filename = "Figures and Tables/graph_ca_country_colored.png",
  plot = graph_ca_country_colored,
  width = 16, height = 11, units = "cm", dpi = 400, bg = "white"
)

# ---------
# CORRESPONDENCE ANALYSIS: Transaction Location × Payment Method
# Prepare data
ca_data_location <- data_POS %>%
  filter(
    !is.na(Transaction_Location),
    !is.na(Transaction_PaymentInstrument),
    Transaction_PaymentInstrument != "Other"
  ) %>%
  mutate(Payment_Grouped = case_when(
    Transaction_PaymentInstrument == "Cash" ~ "Cash",
    Transaction_PaymentInstrument == "Card" ~ "Card",
    Transaction_PaymentInstrument == "Mobile" ~ "Mobile",
    Transaction_PaymentInstrument == "BankTransfer" ~ "Bank Transfer"
  )) %>%
  mutate(
    Transaction_Location = factor(Transaction_Location),
    Payment_Grouped = factor(Payment_Grouped)
  )
# Create contingency table
tab_location <- table(ca_data_location$Transaction_Location, ca_data_location$Payment_Grouped)
# Perform CA
ca_location <- CA(tab_location, graph = FALSE)
# Extract dimension labels
dim1 <- paste0("Dim 1 (", round(ca_location$eig[1, 2], 1), "%)")
dim2 <- paste0("Dim 2 (", round(ca_location$eig[2, 2], 1), "%)")
# Define location groups
Location_group1 <- c("Durable Goods Shop", "Hotel", "Petrol Station",
                     "Private Payment", "Public Authority/Post Office",
                     "Services Outside Home", "Services Inside Home")
Location_group2 <- c("Culture/Sports/Entertainment", "Other Physical Location",
                     "Pick-up Station", "Supermarket")
Location_group3 <- c("Charity", "Day-to-Day Shops", "Restaurant/Bar/Cafe",
                     "Street Vendor/Market", "Vending Machine/Ticketing")

# Location grouping function
assign_location_group <- function(location) {
  if (location %in% Location_group1) return("Group 1")
  if (location %in% Location_group2) return("Group 2")
  if (location %in% Location_group3) return("Group 3")
  return(NA)
}
# Assign location groups
location_groups <- sapply(rownames(ca_location$row$coord), assign_location_group)
# Define group colors
group_colors <- c(
  "Group 1" = "#F8766D", "Group 2" = "#7CAE00", "Group 3" = "#00BFC4"
)
# Map colors to locations
row_colors <- group_colors[location_groups]
# Create colored CA plot
graph_ca_location_colored <- fviz_ca_biplot(
  ca_location,
  repel = TRUE,
  col.row = row_colors,
  col.col = "black",
  arrows = c(TRUE, TRUE),
  label = "all"
) +
  scale_color_identity() +
  coord_fixed(ratio = 1) +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 10)) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 6)) +
  labs(x = dim1, y = dim2) +
  theme_minimal(base_family = "Times New Roman", base_size = 14) +
  theme(
    panel.grid.major = element_line(color = "grey93"),
    legend.position = "none"
  )

# Save colored plot
ggsave(
  filename = "Figures and Tables/graph_ca_location_colored.png",
  plot = graph_ca_location_colored,
  width = 16, height = 11, units = "cm", dpi = 400, bg = "white"
)

# ------------------------------------------------------
# H2: CHOICE IN PAYMENT METHOD
# ------------------------------------------------------
# Create binary Cash vs Non-Cash
data_POS$Cash_vs_NonCash <- ifelse(data_POS$Transaction_PaymentInstrument == "Cash", "Cash", "Non-Cash")
data_POS$Cash_vs_NonCash <- factor(data_POS$Cash_vs_NonCash)
data_POS$Transaction_InstrumentChoiceAvailable <- factor(data_POS$Transaction_InstrumentChoiceAvailable)
# Frequency tables (descriptives)
table(data_POS$Transaction_InstrumentChoiceAvailable)
prop.table(table(data_POS$Cash_vs_NonCash, data_POS$Transaction_InstrumentChoiceAvailable), margin = 1)

# MODEL A: Choice = Yes
model_h2_choice <- lm(
  log(Transaction_Amount) ~ Transaction_PaymentInstrument + Country + Transaction_Location +
    DEM_Age + DEM_Income + DEM_Gender + DEM_HouseholdSize + DEM_ActivityStatus,
  data = subset(data_POS, Transaction_InstrumentChoiceAvailable == "Yes")
)
vcov_choice <- vcovCL(model_h2_choice, cluster = ~ID)

# MODEL B: Choice = No
model_h2_nochoice <- lm(
  log(Transaction_Amount) ~ Transaction_PaymentInstrument + Country + Transaction_Location +
    DEM_Age + DEM_Income + DEM_Gender + DEM_HouseholdSize + DEM_ActivityStatus,
  data = subset(data_POS, Transaction_InstrumentChoiceAvailable == "No")
)
vcov_nochoice <- vcovCL(model_h2_nochoice, cluster = ~ID)

# MODEL C: Interaction model
model_h2_interact <- lm(
  log(Transaction_Amount) ~ Transaction_PaymentInstrument * Transaction_InstrumentChoiceAvailable 
  + Country + Transaction_Location + DEM_Age + DEM_Income +
    DEM_Gender + DEM_HouseholdSize + DEM_ActivityStatus,
  data = data_POS
)
vcov_interact <- vcovCL(model_h2_interact, cluster = ~ID)

# Combined Weighted R²
n_choice    <- nrow(subset(data_POS, Transaction_InstrumentChoiceAvailable == "Yes"))
n_nochoice  <- nrow(subset(data_POS, Transaction_InstrumentChoiceAvailable == "No"))
n_total     <- n_choice + n_nochoice
r2_choice   <- summary(model_h2_choice)$r.squared
r2_nochoice <- summary(model_h2_nochoice)$r.squared
r2_interact <- summary(model_h2_interact)$r.squared
combined_r2 <- (n_choice / n_total) * r2_choice + (n_nochoice / n_total) * r2_nochoice

# Export Regression Table
ft_h2 <- modelsummary(
  models = list(
    "Choice Available Only" = model_h2_choice,
    "No Choice Available"   = model_h2_nochoice,
    "Interaction Model"     = model_h2_interact
  ),
  vcov = list(vcov_choice, vcov_nochoice, vcov_interact),
  statistic = "std.error",
  stars = TRUE,
  output = "flextable"
) |>
  fontsize(size = 10, part = "all") |>
  autofit() |>
  add_footer_lines(values = c(
    sprintf("R-squared (Choice only): %.3f", r2_choice),
    sprintf("R-squared (No choice): %.3f", r2_nochoice),
    sprintf("R-squared (Interaction): %.3f", r2_interact),
    sprintf("Combined weighted R-squared: %.3f", combined_r2)
  ))
# Save to Word
save_as_docx(ft_h2, path = file.path("Figures and Tables", "Table_H2_Choice_Methods_OLS.docx"))

# ASSUMPTIONS 
fig_h2_choice <- check_ols_assumptions(
  model = model_h2_choice,
  model_name = "H2_Choice_Only",
  save_path = "Figures and Tables"
)
fig_h2_nochoice <- check_ols_assumptions(
  model = model_h2_nochoice,
  model_name = "H2_NoChoice_Only",
  save_path = "Figures and Tables"
)
fig_h2_interact <- check_ols_assumptions(
  model = model_h2_interact,
  model_name = "H2_Interaction_Model",
  save_path = "Figures and Tables"
)
# VIF CHECKS
vif_h2_choice    <- vif(model_h2_choice)
vif_h2_nochoice  <- vif(model_h2_nochoice)







